// popup.js — 인트라넷 딸깍

const $ = id => document.getElementById(id);
const MEMBERS = ["구민석","한영채","주지현","박나진","김본희","구정현","박지수"];
const DEFAULT_URL = "https://script.google.com/macros/s/AKfycbzpYvgADNXn3POEe-XDsOVR9Q1AvH_xJ_d38vymNNkjdKCtjtEIiSJJVrpX61FA_6wGbg/exec";
const MAX_HISTORY = 20;

let myName = "", sheetUrl = "", parsedData = null;

// ── 즉시 웜업 ────────────────────────────────────────────────
chrome.storage.local.get(["sheetUrl"], d => {
  fetch((d.sheetUrl || DEFAULT_URL) + "?warmup=1").catch(() => {});
});

// ── 상태/필드 헬퍼 ──────────────────────────────────────────
function showStatus(msg, type) {
  const el = $("status-msg");
  if (el) { el.textContent = msg; el.className = "status " + (type || "info"); }
}

function setField(id, value) {
  const el = $(id);
  if (!el) return;
  el.textContent = value || "—";
  el.className = value ? "fval" : "fval empty";
}

// 다양한 날짜 표기를 <input type="date">용 YYYY-MM-DD로 변환
function toDateInputValue(s) {
  if (!s) return "";
  const m = String(s).match(/(\d{4})\D*(\d{1,2})\D*(\d{1,2})/);
  if (!m) return "";
  return m[1] + "-" + m[2].padStart(2, "0") + "-" + m[3].padStart(2, "0");
}

// ── 탭 전환 ─────────────────────────────────────────────────
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    $("tab-" + tab.dataset.tab).classList.add("active");
    if (tab.dataset.tab === "fetch")   refreshFetchTab();
    if (tab.dataset.tab === "history") loadHistory();
  });
});

// ── 설정 로드 ────────────────────────────────────────────────
function loadSettings(cb) {
  chrome.storage.local.get(["myName", "sheetUrl", "dupCheck", "memoPSuffix"], d => {
    myName   = d.myName   || "";
    sheetUrl = d.sheetUrl || DEFAULT_URL;
    if (d.myName) $("s-myname").value = d.myName;
    $("s-sheet-url").value  = sheetUrl;
    $("s-dupcheck").checked = d.dupCheck !== false;
    const mpt = $("memo-p-toggle"); if (mpt) mpt.checked = !!d.memoPSuffix;
    if (cb) cb();
  });
}

// 토글 즉시 저장
document.addEventListener("DOMContentLoaded", () => {
  $("s-dupcheck")?.addEventListener("change", e => {
    chrome.storage.local.set({ dupCheck: e.target.checked });
  });
  $("memo-p-toggle")?.addEventListener("change", e => {
    chrome.storage.local.set({ memoPSuffix: e.target.checked });
  });
  // 팝업 어디서든 Enter = '구글 시트로 전송' 버튼 클릭과 동일.
  // 단, 아래 경우엔 그 요소 본래 동작을 살리려고 비켜감:
  //  - 한글 조합을 끝내는 Enter(조합 확정 직후 오전송 방지)
  //  - select/드롭다운, 버튼, 링크, 체크박스 등(이름 선택·토글의 기본 Enter 보존)
  //  - 가져오기 탭이 아니거나 메인 입력 화면이 아닐 때(기록/설정 탭에서는 무시)
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    if (e.isComposing || e.keyCode === 229) return;
    const t = e.target;
    const tag = (t && t.tagName) ? t.tagName.toUpperCase() : "";
    const type = (t && t.type) ? String(t.type).toLowerCase() : "";
    if (tag === "SELECT" || tag === "BUTTON" || tag === "A" || tag === "TEXTAREA") return;
    if (type === "checkbox" || type === "radio") return;
    const fetchPanel = $("tab-fetch");
    const mainState  = $("state-main");
    if (!fetchPanel || !fetchPanel.classList.contains("active")) return; // 가져오기 탭에서만
    if (!mainState || mainState.style.display === "none") return;        // 게시글 불러온 메인 화면에서만
    e.preventDefault();
    $("btn-send")?.click(); // 버튼이 비활성(전송 불가 상태)이면 자연히 무시됨
  });
  // 희망완료일: 칸을 클릭하면 캘린더 열기 / 고르면 텍스트칸을 ISO로 채움
  const dueText = $("f-duedate"), duePicker = $("f-duedate-picker");
  dueText?.addEventListener("click", () => {
    try { duePicker.showPicker(); }
    catch (e) { duePicker.focus(); duePicker.click(); } // 폴백
  });
  duePicker?.addEventListener("change", e => {
    if (e.target.value) dueText.value = e.target.value; // YYYY-MM-DD
  });
});

// ── 설정 저장 ────────────────────────────────────────────────
$("btn-save").addEventListener("click", () => {
  const name = $("s-myname").value;
  const url  = $("s-sheet-url").value.trim();
  if (!name || !url) { alert(!name ? "이름을 선택해주세요." : "URL을 입력해주세요."); return; }
  chrome.storage.local.set({ myName: name, sheetUrl: url, dupCheck: $("s-dupcheck").checked }, () => {
    myName = name; sheetUrl = url;
    const b = $("btn-save");
    b.textContent = "저장됐어요"; b.style.background = "#2563eb";
    setTimeout(() => { b.textContent = "저장"; b.style.background = ""; }, 2000);
    refreshFetchTab();
  });
});

// ── 연결 테스트 ──────────────────────────────────────────────
$("btn-test").addEventListener("click", async () => {
  const url = $("s-sheet-url").value.trim();
  const b = $("btn-test");
  if (!url) { b.textContent = "URL을 입력해주세요"; setTimeout(() => { b.textContent = "연결 테스트"; }, 2000); return; }
  b.textContent = "확인 중...";
  try {
    const data = await fetch(url + "?test=1").then(r => r.json());
    b.textContent = data.ok ? "연결 성공!" : "응답 오류";
    b.style.color = data.ok ? "#2563eb" : "#dc2626";
  } catch {
    b.textContent = "연결 실패"; b.style.color = "#dc2626";
  }
  setTimeout(() => { b.textContent = "연결 테스트"; b.style.color = ""; }, 2500);
});

// ── 기록 (chrome.storage.sync) ──────────────────────────────
// sync는 항목당 8KB 제한 → 제목 길이 제한 + 전체 크기 초과 시 오래된 것부터 제거
function saveHistory(item) {
  chrome.storage.sync.get(["history"], d => {
    let hist = (d.history || []).filter(h => h.url !== item.url);
    const slim = { title: (item.title || "").slice(0, 60), url: item.url || "", date: item.date };
    hist.unshift(slim);
    if (hist.length > MAX_HISTORY) hist = hist.slice(0, MAX_HISTORY);
    // sync 8KB 한도 안에 들어오도록 안전 여유(7500바이트)까지 축소
    while (hist.length > 1 && JSON.stringify({ history: hist }).length > 7500) hist.pop();
    chrome.storage.sync.set({ history: hist }, () => {
      if (chrome.runtime.lastError) {
        // 동기화 실패 시 최소한 이 PC에는 보이도록 로컬에 저장
        chrome.storage.local.set({ history: hist });
      }
    });
  });
}

function loadHistory() {
  chrome.storage.sync.get(["history"], d => {
    if (d.history && d.history.length) return renderHistory(d.history);
    // sync에 없으면 로컬 폴백 확인
    chrome.storage.local.get(["history"], l => renderHistory(l.history || []));
  });
}

function renderHistory(hist) {
    const listEl  = $("history-list");
    const emptyEl = $("history-empty");
    const footerEl = $("history-footer");
    emptyEl.style.display  = hist.length ? "none"  : "block";
    footerEl.style.display = hist.length ? "block" : "none";
    listEl.innerHTML = hist.map(h => `
      <a class="history-item" href="${h.url}" target="_blank">
        <div class="history-meta">
          <div class="history-title">${h.title || h.url}</div>
          <div class="history-date">${h.date}</div>
        </div>
      </a>`).join("");
}

$("btn-clear-history").addEventListener("click", () => {
  const b = $("btn-clear-history");
  if (b.dataset.confirm !== "1") {
    b.style.background = "#dc2626"; b.style.color = "#fff";
    b.textContent = "정말 삭제하시겠어요?"; b.dataset.confirm = "1";
    setTimeout(() => {
      b.style.background = "#f2f2f2"; b.style.color = "#1a1a1a";
      b.textContent = "기록 전체 삭제"; b.dataset.confirm = "0";
    }, 3000);
    return;
  }
  chrome.storage.sync.remove("history", () => {
    chrome.storage.local.remove("history", () => {
      b.style.background = "#f2f2f2"; b.style.color = "#1a1a1a";
      b.textContent = "기록 전체 삭제"; b.dataset.confirm = "0";
      loadHistory();
    });
  });
});

// ── 가져오기 탭 갱신 ────────────────────────────────────────
function refreshFetchTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const isIntranet = (tabs[0]?.url || "").includes("intranet.adef.co.kr/video/view");
    $("state-not-intranet").style.display = "none";
    $("state-no-settings").style.display  = "none";
    $("state-main").style.display         = "none";

    if (!isIntranet) {
      $("state-not-intranet").style.display = "block";
    } else if (!myName || !sheetUrl) {
      $("state-no-settings").style.display = "block";
    } else {
      $("state-main").style.display = "block";
      if (!parsedData) parseTab(tabs[0].id);
      else { showStatus(myName + " 시트로 전송됩니다", "success"); $("btn-send").disabled = false; }
    }
  });
}

// ── 초기 화면 ────────────────────────────────────────────────
loadSettings(() => {
  if (!myName) {
    document.querySelectorAll(".tab, .tab-panel").forEach(el => el.classList.remove("active"));
    document.querySelector('[data-tab="settings"]').classList.add("active");
    $("tab-settings").classList.add("active");
  } else {
    refreshFetchTab();
  }
});

// ── 불러오기 ────────────────────────────────────────────────
function parseTab(tabId) {
  showStatus("불러오는 중...", "info");
  chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
    if (chrome.runtime.lastError) { showStatus("불러오기 실패: " + chrome.runtime.lastError.message, "error"); return; }
    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, { action: "parsePage" }, res => {
        if (chrome.runtime.lastError) { showStatus("불러오기 오류: " + chrome.runtime.lastError.message, "error"); return; }
        render(res);
      });
    }, 200);
  });
}

function render(res) {
  if (!res?.success) { showStatus("불러오기 실패: " + (res?.error || "오류"), "error"); return; }
  parsedData = res.data;

  $("f-title").value   = parsedData.title || "";
  const dueISO = toDateInputValue(parsedData.dueDate);
  $("f-duedate").value = dueISO;
  $("f-duedate-picker").value = dueISO;
  setField("f-assignee", parsedData.assignee);
  $("f-memo").value = ""; // 새 게시글 불러오면 메모 초기화(이전 메모 섞임 방지)

  const tag = $("f-assignee-tag");
  if (MEMBERS.includes(parsedData.assignee)) {
    tag.textContent = "개인"; tag.className = "assignee-tag badge me"; tag.style.display = "";
  } else if (parsedData.assignee) {
    tag.textContent = "공동"; tag.className = "assignee-tag badge team"; tag.style.display = "";
  } else {
    tag.style.display = "none";
  }

  const sel = $("f-links");
  sel.innerHTML = '<option value="">— 선택하세요 —</option>';
  const groups = { link: "🔗 외부 링크", nas: "📁 NAS 경로", file: "📎 첨부파일" };
  const grouped = {};
  (parsedData.linkCandidates || []).forEach(c => {
    const t = c.type || "link";
    (grouped[t] = grouped[t] || []).push(c);
  });
  Object.entries(groups).forEach(([type, label]) => {
    if (!grouped[type]?.length) return;
    const og = document.createElement("optgroup");
    og.label = label;
    grouped[type].forEach(c => {
      const o = document.createElement("option");
      o.value = c.value; o.textContent = c.label.slice(0, 60);
      og.appendChild(o);
    });
    sel.appendChild(og);
  });
  if (parsedData.linkCandidates?.length) sel.selectedIndex = 1;

  $("btn-send").disabled = false;
  showStatus(myName + " 시트로 전송됩니다", "success");
}

$("btn-parse").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => parseTab(tabs[0].id));
});

// ── 전송 ────────────────────────────────────────────────────
$("btn-send").addEventListener("click", async () => {
  // 직접 입력칸이 있으면 그걸 우선 (없을 때만 드롭다운 선택값)
  const planLink = $("f-link-custom").value.trim() || $("f-links").value;
  const { dupCheck } = await new Promise(r => chrome.storage.local.get(["dupCheck"], r));

  showStatus("구글 시트로 전송 중...", "info");
  $("btn-send").disabled = true;

  // 메모: p토글이 켜져 있고 내용이 있으면 끝에 'p' 추가 (예: 1,2,3 → 1,2,3p)
  let memoVal = $("f-memo").value.trim();
  if (memoVal && $("memo-p-toggle")?.checked) memoVal += "p";

  const body = new URLSearchParams({
    targetMember: myName,
    title:        $("f-title").value.trim()    || "",
    dueDate:      toDateInputValue($("f-duedate").value) || "",
    planLink:     planLink             || "",
    memo:         memoVal              || "",
    url:          parsedData?.url      || "",
    dupCheck:     dupCheck !== false   ? "1" : "0",
  }).toString();

  try {
    const data = await fetch(sheetUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    }).then(r => r.json());

    if (data.duplicate) {
      showStatus("이미 등록된 게시글이에요.", "warn");
      $("btn-send").disabled = false;
    } else if (data.ok) {
      showStatus(myName + " 시트에 추가됐어요!", "success");
      $("f-memo").value = ""; // 전송 성공 시 메모 비움
      saveHistory({
        title: $("f-title").value.trim() || "(제목 없음)",
        url:   parsedData?.url   || "",
        date:  new Date().toLocaleDateString("ko-KR", { month: "2-digit", day: "2-digit" })
                         .replace(". ", "/").replace(".", ""),
      });
    } else {
      showStatus("오류: " + (data.error || "알 수 없는 오류"), "error");
      $("btn-send").disabled = false;
    }
  } catch (e) {
    showStatus("전송 실패: " + e.message, "error");
    $("btn-send").disabled = false;
  }
});
