// ready.js — 페이드 해제의 최후 안전망. popup.js 보다 먼저 로드된다.
//
// body 는 opacity:0 으로 시작하고 popup.js 의 비동기 콜백이 .ready 를 붙여야 보인다.
// 그 콜백이 안 오거나 popup.js 가 최상단에서 던지면 352x404 빈 흰 상자로 남고 사용자가 빠져나올 방법이 없다.
// 이 타이머는 popup.js 와 다른 파일이라 그 예외에 같이 죽지 않는다. 정상 경로는 수십 ms 안에 ready 가 붙어 보이지 않는다.
//
// ★ 인라인 <script> 로 두면 안 된다 — MV3 기본 CSP(script-src 'self')가 인라인을 차단해
//   chrome://extensions 에 오류가 찍히고 타이머는 실행조차 안 된다(2026-09-08 ~ 09-18 그 상태로 배포됐었다).
//   하네스(일반 HTML)는 CSP 를 재현하지 못하므로 거기서 통과해도 확장에서는 죽는다.
setTimeout(function () { document.body.classList.add("ready"); }, 1200);
