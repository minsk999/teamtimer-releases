// content.js — intranet.adef.co.kr 전용 파서 v5

(function () {
  "use strict";

  // 이 파일은 manifest 로 자동 주입되고, 팝업이 executeScript 로 또 넣을 수도 있다.
  // 가드가 없으면 주입할 때마다 onMessage 리스너가 쌓여서
  // 팝업을 열 때마다 문서 전체 스캔이 한 번씩 더 돈다.
  if (window.__ttalkakParserLoaded) return;
  window.__ttalkakParserLoaded = true;

  function getParam(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  // ── 레이블로 값 찾기 ─────────────────────────────────────
  // "제목", "기획안 링크" 등 .view_form__title 텍스트로 옆 값 탐색
  // 라벨 텍스트 비교 — 뒤에 붙는 콜론·별표·공백은 무시한다.
  // 인트라넷이 "제목" 을 "제목 :" 으로 바꾸는 날 통째로 멈추던 것.
  function labelMatches(el, labelText) {
    return el.innerText.trim().replace(/[\s:：*]+$/, "") === labelText;
  }

  // 레이블 옆 컨테이너를 돌려준다. 제목·링크 탐색이 같은 규칙을 쓰도록 한 곳에 둔다.
  function contentByLabel(labelText) {
    const titles = document.querySelectorAll(".view_form__title");
    for (const el of titles) {
      if (labelMatches(el, labelText)) return el.nextElementSibling || null;
    }
    return null;
  }

  // 레이블 옆 <a> 태그 링크 수집.
  // primary = '기획안 링크' 라벨에서 직접 나온 것. 팝업은 이게 있을 때만 자동 선택한다.
  function getLinksByLabel(labelText) {
    const content = contentByLabel(labelText);
    if (!content) return [];
    return Array.from(content.querySelectorAll("a[href]"))
      .map(a => ({ type: "link", label: a.innerText.trim() || a.href, value: a.href, primary: true }));
  }

  // ── 기획안 링크 후보 수집 ────────────────────────────────
  function collectPlanLinks() {
    const results = [];
    const seen = new Set();

    function add(item) {
      if (!item.value || seen.has(item.value)) return;
      seen.add(item.value);
      results.push(item);
    }


    // ① "기획안 링크" 레이블 옆 링크 우선
    getLinksByLabel("기획안 링크").forEach(add);
    getLinksByLabel("기획안").forEach(add);

    // ② .view_form__content--anchor (구글드라이브 등)
    document.querySelectorAll(".view_form__content--anchor").forEach(a => {
      if (a.href && a.href !== "#") add({ type: "link", label: a.innerText.trim() || a.href, value: a.href });
    });

    // ③ .view_form__content 내 모든 <a>
    document.querySelectorAll(".view_form__content a[href]").forEach(a => {
      if (a.href && a.href !== "#") add({ type: "link", label: a.innerText.trim() || a.href, value: a.href });
    });

    // ④ NAS 경로 텍스트
    document.querySelectorAll(".view_form__content").forEach(container => {
      const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        const t = node.textContent.trim();
        if (t.length < 5) continue;
        // 예전엔 "문자열 어딘가에 /nas/ 가 있으면" 텍스트 노드 전체를 값으로 넣었다.
        // 그래서 "소스는 /nas/video/2026/ 에 있습니다. 확인 부탁드려요." 한 문장이
        // 통째로 시트 링크 칸에 들어갔다. 매칭이 아니라 추출로 바꾼다.
        const m = t.match(/(?:^|\s)((?:\/(?:cr|nas|server)\/)[^\s]*)/i);
        if (m) {
          add({ type: "nas", label: m[1].slice(0, 100), value: m[1].slice(0, 500) });
        }
      }
    });

    // ⑤ 첨부파일 — 본문 안에서만. 예전엔 문서 전체를 훑어
    //    헤더·푸터의 '이용안내.pdf' 같은 것까지 후보로 올라왔다.
    document.querySelectorAll(".view_form__content a[href]").forEach(a => {
      if (/\.(pptx?|xlsx?|docx?|pdf|zip)(\?|$)/i.test(a.href)) {
        add({ type: "file", label: a.innerText.trim() || a.href.split("/").pop(), value: a.href });
      }
    });

    return results;
  }

  // ── 기획안 쪽 번호 ───────────────────────────────────────
  // 본문에 적힌 쪽 번호를 나온 순서대로 모은다(범위는 첫 번호만). 표기는 2026-11-27 게시글 585건 실측:
  //   뒤에 붙임  53~55페이지 · 49~53p · 24P-32P · 4 - 6 페이지 · 207 슬라이드 · 34, 35p · 552.-553p(오타)
  //   앞에 붙임  p.64-65 · P. 110 · p1~6 · P58-60
  //   라벨      ★ 슬라이드 : 206, 207 · 슬라이드 18-21
  // 「장」은 뺀다(「3장 만들어 주세요」처럼 개수로도 쓴다). 링크 주소는 먼저 지운다(주소 속 「p53」 오인).
  // <planpage> — test/plan-page.test.js 가 이 구간을 잘라 시험한다
  function findPlanPages(text) {
    const t = String(text || "").replace(/https?:\/\/\S+/g, " ");
    const N = "(\\d{1,3})";                        // 1080p 같은 해상도는 네 자리라 안 걸린다
    const MORE = "(?:\\.?\\s*[pP]?\\s*[,~\\-–]\\s*[pP]?\\.?\\s*\\d{1,3})*";   // ~55 · -32P · , 35 · .-553
    const res = [
      // 범위 끝(「p16-18 페이지」의 18)은 따로 세지 않는다
      new RegExp("(?<![\\w.]|[~\\-–]\\s*)" + N + "\\s*[pP]?" + MORE + "\\s*(?:페이지|쪽|슬라이드|[pP](?![a-zA-Z]))", "g"),
      new RegExp("(?<![A-Za-z0-9])[pP]\\.?\\s*" + N + "(?!\\d)", "g"),
      new RegExp("(?:슬라이드|페이지|page)\\s*[:：]?\\s*" + N + "(?![\\d가-힣])", "gi"),
    ];
    const hits = [];
    for (const re of res) for (const m of t.matchAll(re)) {
      const n = Number(m[1]);
      if (n) hits.push({ at: m.index, n });
    }
    hits.sort((a, b) => a.at - b.at);
    return [...new Set(hits.map(h => h.n))];
  }
  // </planpage>

  // ── 메인 파싱 ────────────────────────────────────────────
  function parsePageData() {

    // ① 제목 — "제목" 레이블 옆 .view_form__content--txt
    const titleBox = contentByLabel("제목");
    const titleEl = titleBox ? titleBox.querySelector(".view_form__content--txt") : null;
    // 구조가 바뀌어 --txt 가 없어도 컨테이너 텍스트로 한 번 더 시도한다
    const title = titleEl ? titleEl.innerText.trim()
                : (titleBox ? titleBox.innerText.trim() : null);

    // ② 희망완료일
    const dueDateEl = document.querySelector("input[name='end_date']");
    const dueDate = dueDateEl ? dueDateEl.value.trim() : null;

    // ③ 처리자 — select#crlist 선택된 option
    const assigneeEl = document.querySelector("select#crlist");
    let assignee = null;
    if (assigneeEl) {
      const sel = assigneeEl.querySelector("option[selected]")
                || assigneeEl.options[assigneeEl.selectedIndex];
      assignee = sel ? sel.innerText.trim() : null;
    }

    // ④ 기획안 링크 후보
    const linkCandidates = collectPlanLinks();

    return {
      url: window.location.href,
      idx: getParam("idx"),
      title,
      dueDate,
      assignee,
      linkCandidates,
      // 비고가 본문. 라벨을 못 찾으면 제목만 본다(문서 전체는 링크 주소 속 숫자까지 걸린다)
      planPages: findPlanPages([title, contentByLabel("비고")?.innerText].join("\n")),
    };
  }

  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.action !== "parsePage") return;   // 다른 메시지는 건드리지 않는다
    try {
      sendResponse({ success: true, data: parsePageData() });
    } catch (e) {
      sendResponse({ success: false, error: e.message });
    }
    // 동기로 응답을 마쳤으므로 채널을 열어 둘 이유가 없다 (return true 제거)
  });
})();
