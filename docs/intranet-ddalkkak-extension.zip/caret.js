/* 부드러운 커서 — 글자를 치면 커서가 다음 자리로 건너뛰지 않고 미끄러져 따라간다(워드의 타자 느낌).
   정본 = nas-gallery public/app.js 끝 블록(11-27 · 라이트 다운로더 Field · BannerNode #scaret · 글꼴함 caret.js 와 같은 값).
   딸깍 v1.8.12 에 그대로 옮겼다 — 고칠 땐 정본과 같이.
   방식: 그 칸의 기본 커서는 인라인 caret-color 로 감추고, 글자 폭을 같은 글꼴의 숨은 줄로 재서 #scaret 을 그 자리에 그린다.
   값: 폭 2px · 남은 거리를 시간 상수 28ms 로 줄임(0.06초에 약 90%) · 치는 동안 켜져 있고 쉬면 530ms 로 깜빡임 ·
       다른 칸에서 넘어오면 미끄러지지 않고 제자리 · 윈도우 「애니메이션 효과」를 끈 PC 는 바로 옮김 · 색 = 그 칸의 글자색.
   대상: 마우스가 있는 기기의 한 줄 글자 칸만(읽기 전용·꺼진 칸·체크박스·날짜는 기본 커서 그대로).
   커서 자리를 다른 것이 덮거나 글자를 고르는 중이면 그리지 않는다. 팝업 CSP 때문에 인라인이 아니라 이 파일로 싣는다. */
(function () {
  const FINE = matchMedia('(hover: hover) and (pointer: fine)');
  const REDUCED = matchMedia('(prefers-reduced-motion: reduce)');
  const car = document.createElement('i'); car.id = 'scaret'; car.setAttribute('aria-hidden', 'true');
  const ruler = document.createElement('span'); ruler.id = 'scaretRuler'; ruler.setAttribute('aria-hidden', 'true');
  const COPY = ['fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'fontStretch', 'fontVariant', 'fontFeatureSettings', 'fontVariationSettings', 'fontKerning', 'letterSpacing', 'wordSpacing', 'textTransform'];
  let el = null, x = null, last = 0, raf = 0, until = 0, mKey = '', mW = 0, mFull = 0, lastA = 1, shift = 0, pOff = null, fdt = 16;
  const ok = e => FINE.matches && e && e.tagName === 'INPUT' && /^(text|search|url|email|tel)$/.test(e.type) && !e.readOnly && !e.disabled;
  function width(cs, t) { COPY.forEach(k => ruler.style[k] = cs[k]); ruler.textContent = t; return ruler.getBoundingClientRect().width; }
  // 칸 안의 길이(padding·글자 폭)는 배율이 안 걸린 값이고 r 은 조상 scale 이 걸린 값이다 — 칸 안의 길이에 배율 s 를 곱한다
  function goal() {
    const cs = getComputedStyle(el), r = el.getBoundingClientRect(), s = el.offsetWidth ? r.width / el.offsetWidth : 1;
    const bl = parseFloat(cs.borderLeftWidth), pl = parseFloat(cs.paddingLeft), pr = parseFloat(cs.paddingRight), bt = parseFloat(cs.borderTopWidth), bb = parseFloat(cs.borderBottomWidth);
    const v = el.value, at = el.selectionEnd == null ? v.length : el.selectionEnd, key = v + '\u0000' + at + '\u0000' + cs.font + cs.letterSpacing;
    if (key !== mKey) { mKey = key; mW = width(cs, v.slice(0, at)); mFull = width(cs, v); }
    const W = el.offsetWidth - bl - pl - pr - parseFloat(cs.borderRightWidth), ta = cs.textAlign;
    const off = mFull < W ? (ta === 'center' ? (W - mFull) / 2 : (ta === 'right' || ta === 'end') ? W - mFull : 0) : 0;
    // 가운데 정렬 칸(쪽 번호)은 한 글자 칠 때마다 글 전체가 반 글자씩 순간 이동한다 — 그 이동분을 text-indent 로 되돌려 같은 속도로 푼다
    if (ta === 'center' && pOff != null && off !== pOff && mFull < W && !REDUCED.matches) shift += pOff - off;
    pOff = off; if (mFull + 2 * Math.abs(shift) >= W) shift = 0;
    const fs = parseFloat(cs.fontSize), h = Math.round(fs * 1.25), H = el.offsetHeight - bt - bb;
    return { x: r.left + s * (bl + pl + Math.min(W, Math.max(0, off + shift + mW - el.scrollLeft))), y: r.top + s * (bt + (H - h) / 2), h: h * s, r, color: cs.color };
  }
  // 조상이 옅어지는 동안 커서도 같이 옅어지게 — 깜빡임 animation 이 opacity 를 쓰므로 filter 로
  function alpha() { let a = 1; for (let n = el; n && n.nodeType === 1 && a > 0.01; n = n.parentElement) a *= parseFloat(getComputedStyle(n).opacity) || 0; return a; }
  function hidden(g) {
    if (el.selectionStart !== el.selectionEnd || !g.r.width || document.visibilityState === 'hidden') return true;
    // 판정 점은 칸 안쪽으로 — 글자 끝이 칸 경계에 닿으면 경계 점이 칸 밖으로 맞아 커서가 사라졌다
    const px = Math.max(g.r.left + 1, Math.min(g.x, g.r.right - 1));
    const hit = document.elementFromPoint(px, g.y + g.h / 2); return !(hit === el || (hit && el.contains(hit)));
  }
  function frame(t) {
    raf = 0; if (!el || document.activeElement !== el) { car.style.display = 'none'; return; }
    // 쉬다 시작하는 첫 프레임은 직전에 잰 프레임 간격으로 — 16ms 로 치면 240Hz 화면에서 첫 걸음이 43% 였다
    const dt = last ? Math.max(1, t - last) : fdt; if (last) fdt = Math.min(34, dt); last = t;
    if (shift) { shift *= Math.exp(-dt / 28); if (Math.abs(shift) < 0.3) shift = 0; }
    const g = goal(), ind = shift ? (shift * 2).toFixed(2) + 'px' : '';
    if (el.style.textIndent !== ind) el.style.textIndent = ind;
    x = (x == null || REDUCED.matches) ? g.x : x + (g.x - x) * (1 - Math.exp(-dt / 28));
    if (Math.abs(g.x - x) < 0.3) x = g.x;
    const a = alpha(), fading = Math.abs(a - lastA) > 0.002; lastA = a;
    if (a < 0.02 || hidden(g)) car.style.display = 'none';
    else { car.style.display = 'block'; car.style.filter = a > 0.995 ? '' : 'opacity(' + a.toFixed(3) + ')'; car.style.background = g.color; car.style.transform = 'translate(' + (x - 1) + 'px,' + g.y + 'px)'; car.style.height = g.h + 'px'; }
    if (x !== g.x || shift || t < until || fading) raf = requestAnimationFrame(frame); else last = 0;
  }
  function kick(blink) {
    if (!el) return; until = performance.now() + 320;   // 탭이 바뀌며 움직이는 동안에도 따라가게 잠깐 더 돈다
    if (blink !== false) { car.classList.remove('bl'); void car.offsetWidth; car.classList.add('bl'); }   // 치는 동안에는 켜져 있다 — 깜빡임을 처음부터 다시
    if (!raf) { last = 0; raf = requestAnimationFrame(frame); }
  }
  function release() { if (el) { el.style.caretColor = ''; el.style.textIndent = ''; } el = null; car.style.display = 'none'; }
  document.addEventListener('focusin', e => {
    const t = e.target; if (!ok(t)) { if (el) release(); return; }
    if (!car.isConnected) { document.body.appendChild(car); document.body.appendChild(ruler); }
    if (el && el !== t) { el.style.caretColor = ''; el.style.textIndent = ''; }
    el = t; t.style.caretColor = 'transparent'; x = null; mKey = ''; shift = 0; pOff = null; kick();
  }, true);
  document.addEventListener('focusout', e => { if (e.target === el) release(); }, true);
  ['input', 'keydown', 'keyup', 'selectionchange', 'compositionstart', 'compositionupdate', 'compositionend', 'pointerup'].forEach(n => document.addEventListener(n, () => kick(), true));
  ['scroll', 'transitionend', 'animationend', 'wheel'].forEach(n => document.addEventListener(n, () => kick(false), { capture: true, passive: true }));
  addEventListener('resize', () => kick(false));
  // 한글 글꼴이 늦게 오면 폭이 바뀌므로 다 받은 뒤 다시 잰다
  if (document.fonts) document.fonts.addEventListener('loadingdone', () => { mKey = ''; kick(false); });
})();
