// BatchRenameComps - clean rebuild

#target aftereffects

(function (thisObj) {

    // ========================================================================
    // ========================================================================
    var IS_PREMIERE = (typeof BridgeTalk !== "undefined" &&
        BridgeTalk.appName.toLowerCase().indexOf("premierepro") !== -1);

    // ========================================================================
    // ========================================================================
    var SETTINGS_FILE = "~/BatchRenameComps_settings.json";

    // 통합 설정 로드/저장 (worker, resPresets, importPath, localTreePath 등)
    function loadSettings() {
        var obj = {};
        try {
            var f = new File(SETTINGS_FILE);
            if (!f.exists) return obj;
            f.encoding = "UTF-8";
            f.open("r");
            var data = f.read();
            f.close();
            if (!data) return obj;
            try {
                obj = (typeof JSON !== "undefined" && JSON.parse)
                    ? JSON.parse(data)
                    : eval("(" + data + ")");
            } catch (pe) { obj = {}; }
        } catch (e) { obj = {}; }
        return obj || {};
    }

    function saveSettings(obj) {
        try {
            var f = new File(SETTINGS_FILE);
            f.encoding = "UTF-8";
            f.open("w");
            var str = (typeof JSON !== "undefined" && JSON.stringify)
                ? JSON.stringify(obj)
                : null;
            if (str === null) {
                // 폴백: 수동 직렬화 (단순 객체 가정)
                var parts = [];
                for (var k in obj) {
                    if (!obj.hasOwnProperty(k)) continue;
                    var v = obj[k];
                    if (v instanceof Array) {
                        var arr = [];
                        for (var i = 0; i < v.length; i++)
                            arr.push('"' + String(v[i]).replace(/"/g, '\\"') + '"');
                        parts.push('"' + k + '":[' + arr.join(",") + ']');
                    } else {
                        parts.push('"' + k + '":"' + String(v).replace(/"/g, '\\"') + '"');
                    }
                }
                str = "{" + parts.join(",") + "}";
            }
            f.write(str);
            f.close();
        } catch (e) {}
    }

    function getSetting(key, fallback) {
        var s = loadSettings();
        return (s[key] !== undefined && s[key] !== null) ? s[key] : fallback;
    }
    function setSetting(key, value) {
        var s = loadSettings();
        s[key] = value;
        saveSettings(s);
    }

    function loadWorker() { return getSetting("worker", "") || ""; }
    function saveWorker(name) { setSetting("worker", String(name)); }

    // ========================================================================
    // ========================================================================
    var RES_LIST = ["None",
        "1920x1080 (16:9)", "1080x1080 (1:1)", "1080x1920 (9:16)",
        "1080x1350 (4:5)", "1200x628 (1.91:1)", "1200x1200 (1:1)",
        "1200x1500 (4:5)", "1440x1440 (1:1)", "1440x1800 (4:5)",
        "3840x2160 (16:9)", "2160x3840 (9:16)"];
    function resCode(label) {
        return String(label).replace(/\s*\(.*\)$/, "");
    }
    var TYPE_LIST = ["None","xian","retuch1","vari","sf"];
    var JOBKIND_LIST = ["None",
        "@MB: \uBAA8\uC158\uBC30\uB108","@BC: \uBC30\uB108\uACB0\uD569","@SZ: \uC0AC\uC774\uC988\uBC30\uB9AC",
        "@ED: \uD3B8\uC9D1","@AV: AI\uD65C\uC6A9\uC601\uC0C1","@AB: AI\uD65C\uC6A9\uBC30\uB108",
        "@MV: \uBAA8\uC158\uC601\uC0C1","@SH: \uCD2C\uC601","@CP: \uC6A9\uB7C9\uBC30\uB9AC"];

    // ========================================================================
    // ========================================================================
    function getTodayYYMMDD() {
        var d = new Date();
        var yy = ("0" + (d.getFullYear() % 100)).slice(-2);
        var mm = ("0" + (d.getMonth() + 1)).slice(-2);
        var dd = ("0" + d.getDate()).slice(-2);
        return yy + mm + dd;
    }

    function trimStr(s) {
        return String(s == null ? "" : s).replace(/^\s+|\s+$/g, "");
    }

    function sanitize(s) {
        return String(s == null ? "" : s)
            .replace(/[\\\/:\*\?"<>\|]/g, "")
            .replace(/\s+/g, " ");
    }

    function ddText(dropdown, fallback) {
        try {
            if (dropdown && dropdown.selection)
                return String(dropdown.selection.text);
        } catch (e) {}
        return fallback;
    }

    function jobKindCode(label) {
        label = String(label || "");
        var i = label.indexOf(":");
        return i !== -1 ? label.substring(0, i) : label;
    }

    // ========================================================================
    // ========================================================================
    function getSelectedItems() {
        var result = [];
        try {
            var sel = app.project.selection;
            if (!sel || !sel.length) return result;
            for (var i = 0; i < sel.length; i++) {
                if (!sel[i]) continue;
                if (typeof CompItem !== "undefined" && sel[i] instanceof CompItem) {
                    result.push(sel[i]);
                } else if (IS_PREMIERE && sel[i].type !== undefined) {
                    result.push(sel[i]);
                }
            }
        } catch (e) {}
        return result;
    }

    function setItemName(item, name) {
        try { item.name = name; } catch (e) {}
    }

    function getItemName(item) {
        try { return String(item.name || ""); } catch (e) { return ""; }
    }

    function withUndo(label, fn) {
        try { app.beginUndoGroup(label); } catch (e) {}
        try { fn(); } catch (e) {}
        try { app.endUndoGroup(); } catch (e) {}
    }

    // ========================================================================
    // ========================================================================
    function stripCopyNum(name) {
        return String(name || "").replace(/\s+\d+$/, "");
    }

    function isDate(p) { return /^\d{6}$/.test(String(p)); }

    function isResolution(p) {
        p = String(p);
        if (/^\d{3,4}[xX]\d{3,4}$/.test(p)) return true;
        for (var i = 1; i < RES_LIST.length; i++)
            if (p === resCode(RES_LIST[i])) return true;
        return false;
    }

    function isWorkType(p) {
        p = String(p || "");
        return p === "xian" || p === "vari" || p === "sf" || /^retuch\d+$/.test(p);
    }

    function isJobKind(p) {
        p = String(p || "");
        for (var i = 1; i < JOBKIND_LIST.length; i++)
            if (p === jobKindCode(JOBKIND_LIST[i])) return true;
        return false;
    }


    function isSpecialToken(p) {
        return isDate(p) || isResolution(p) || isWorkType(p) ||
               isJobKind(p) || /^\d+p$/.test(p);
    }

    function getGenericToken(name, idx) {
        var parts = smartSplit(name);
        var count = 0;
        for (var i = 0; i < parts.length; i++) {
            if (!isSpecialToken(parts[i])) {
                if (count === idx) return parts[i];
                count++;
            }
        }
        return "";
    }

    function smartSplit(name) {
        var rawParts = stripCopyNum(name).split("_");
        var merged = [];
        var i = 0;
        while (i < rawParts.length) {
            var p = rawParts[i];
            if (i + 1 < rawParts.length &&
                /^\d+$/.test(rawParts[i + 1]) &&
                !isSpecialToken(p)) {
                merged.push(p + "_" + rawParts[i + 1]);
                i += 2;
            } else {
                merged.push(p);
                i += 1;
            }
        }
        return merged;
    }

    function applyGenericTo(name, v, genericIndex) {
        var parts = smartSplit(name);
        var count = 0;
        for (var i = 0; i < parts.length; i++) {
            if (!isSpecialToken(parts[i])) {
                if (count === genericIndex) {
                    parts[i] = v;
                    return parts.join("_");
                }
                count++;
            }
        }
        // 해당 인덱스의 generic이 없으면 끝에 추가
        parts.push(v);
        return parts.join("_");
    }

    function applyTaskTo(name, oldVal, newVal) {
        var parts = smartSplit(name);
        if (oldVal) {
            var oldParts = smartSplit(oldVal);
            var oldLen = oldParts.length;
            for (var i = 0; i <= parts.length - oldLen; i++) {
                var match = true;
                for (var j = 0; j < oldLen; j++) {
                    if (parts[i+j] !== oldParts[j]) { match = false; break; }
                }
                if (match) {
                    var newParts = [];
                    for (var k = 0; k < i; k++) newParts.push(parts[k]);
                    newParts.push(newVal);
                    for (var m = i + oldLen; m < parts.length; m++) newParts.push(parts[m]);
                    return newParts.join("_");
                }
            }
        }
        return applyGenericTo(name, newVal, 2);
    }

    function applyPageTo(name, v) {
        var parts = stripCopyNum(name).split("_");
        var newToken = v + "p";
        for (var i = 0; i < parts.length; i++) {
            if (/^\d+p$/.test(parts[i])) {
                parts[i] = newToken;
                return parts.join("_");
            }
        }
        var genericCount = 0;
        for (var j = 0; j < parts.length; j++) {
            if (!isSpecialToken(parts[j])) {
                genericCount++;
                if (genericCount === 2) {
                    parts.splice(j + 1, 0, newToken);
                    return parts.join("_");
                }
            }
        }
        parts.push(newToken);
        return parts.join("_");
    }

    function applyWorkerTo(name, v) {
        var parts = stripCopyNum(name).split("_");
        for (var i = 1; i < parts.length; i++) {
            if (/^@/.test(parts[i]) && isJobKind(parts[i]) &&
                /^[A-Z]{2,5}$/.test(parts[i-1])) {
                parts[i-1] = v;
                return parts.join("_");
            }
        }
        for (var j = parts.length - 1; j >= 0; j--) {
            if (/^[A-Z]{2,5}$/.test(parts[j])) {
                parts[j] = v;
                return parts.join("_");
            }
        }
        var idx = parts.length;
        for (var k = 0; k < parts.length; k++) {
            if (/^@/.test(parts[k]) && isJobKind(parts[k])) { idx = k; break; }
        }
        parts.splice(idx, 0, v);
        return parts.join("_");
    }
    function applyDateTo(name, v) {
        var parts = stripCopyNum(name).split("_");
        if (parts.length > 0 && isDate(parts[0])) parts[0] = v;
        else parts.unshift(v);
        return parts.join("_");
    }

    function applyResTo(name, v) {
        var parts = stripCopyNum(name).split("_");
        for (var i = 0; i < parts.length; i++) {
            if (isResolution(parts[i])) { parts[i] = v; return parts.join("_"); }
        }
        var insertIdx = parts.length;
        for (var j = 1; j < parts.length; j++) {
            if (/^@/.test(parts[j]) && isJobKind(parts[j]) &&
                /^[A-Z]{2,5}$/.test(parts[j-1])) {
                insertIdx = j - 1;
                break;
            }
        }
        if (insertIdx === parts.length) {
            for (var k = 0; k < parts.length; k++) {
                if (/^@/.test(parts[k]) && isJobKind(parts[k])) {
                    insertIdx = k; break;
                }
            }
        }
        if (insertIdx === parts.length) {
            for (var m = parts.length - 1; m >= 0; m--) {
                if (/^[A-Z]{2,5}$/.test(parts[m])) { insertIdx = m; break; }
            }
        }
        parts.splice(insertIdx, 0, v);
        return parts.join("_");
    }

    function applyJobKindTo(name, v) {
        v = jobKindCode(v);
        var parts = stripCopyNum(name).split("_");
        for (var i = 0; i < parts.length; i++) {
            if (isJobKind(parts[i])) { parts[i] = v; return parts.join("_"); }
        }
        var idx = (parts.length >= 1 && isWorkType(parts[parts.length-1]))
                  ? parts.length - 1 : parts.length;
        parts.splice(idx, 0, v);
        return parts.join("_");
    }

    function applyTypeTo(name, v) {
        var parts = stripCopyNum(name).split("_");
        var isRetuchInput = /^retuch\d+$/.test(v);
        for (var i = 0; i < parts.length; i++) {
            if (isWorkType(parts[i])) {
                if (isRetuchInput && /^retuch(\d+)$/.test(parts[i])) {
                    var m = parts[i].match(/^retuch(\d+)$/);
                    var n = parseInt(m[1], 10) + 1;
                    parts[i] = "retuch" + n;
                } else {
                    parts[i] = v;
                }
                return parts.join("_");
            }
        }
        parts.push(v);
        return parts.join("_");
    }

    // ========================================================================
    function createFolderTree(mode) {
        var proj = app.project;

        function makeFolder(name, parent) {
            var parentFolder = parent || proj.rootFolder;
            for (var i = 1; i <= proj.numItems; i++) {
                var item = proj.item(i);
                if (item.name === name && item instanceof FolderItem &&
                    item.parentFolder === parentFolder) return item;
            }
            var f = proj.items.addFolder(name);
            if (parent) f.parentFolder = parent;
            return f;
        }

        var beforeItems = [];
        for (var i = 1; i <= proj.numItems; i++) {
            if (proj.item(i).parentFolder === proj.rootFolder)
                beforeItems.push(proj.item(i));
        }

        if (beforeItems.length > 0) {
            var stock = makeFolder("Stock");
            for (var k = 0; k < beforeItems.length; k++) {
                try {
                    if (beforeItems[k] !== stock)
                        beforeItems[k].parentFolder = stock;
                } catch(e) {}
            }
        }

        if (mode === "quick") {
            makeFolder("00_Master");
            makeFolder("01_Comp");
            var f02 = makeFolder("02_Sc");
                makeFolder("Image", f02);
                makeFolder("Video", f02);
            makeFolder("03_Ref");
        } else {
            makeFolder("00_Master");
            var f01 = makeFolder("01_Comp");
                makeFolder("_Main", f01);
                makeFolder("Etc", f01);
            var f02 = makeFolder("02_Sc");
                var fImg = makeFolder("Image", f02);
                    makeFolder("LOGO", fImg);
                    makeFolder("Rester", fImg);
                    makeFolder("Vector", fImg);
                makeFolder("Project", f02);
                var fVid = makeFolder("Video", f02);
                    makeFolder("Original", fVid);
                    makeFolder("Render", fVid);
                    makeFolder("Source", fVid);
            var f03 = makeFolder("03_Mix");
                makeFolder("BGM", f03);
                makeFolder("Nar", f03);
                makeFolder("SE", f03);
            makeFolder("Ref");
        }
    }

    // ========================================================================
    // 확장자 → 분류 폴더 경로(02_Sc 하위) 매핑 (full 트리 기준)
    // ========================================================================
    var EXT_MAP = {
        // raster
        "jpg":["02_Sc","Image","Rester"],"jpeg":["02_Sc","Image","Rester"],
        "png":["02_Sc","Image","Rester"],"gif":["02_Sc","Image","Rester"],
        "bmp":["02_Sc","Image","Rester"],"tif":["02_Sc","Image","Rester"],
        "tiff":["02_Sc","Image","Rester"],"tga":["02_Sc","Image","Rester"],
        "exr":["02_Sc","Image","Rester"],"hdr":["02_Sc","Image","Rester"],
        "dpx":["02_Sc","Image","Rester"],"cin":["02_Sc","Image","Rester"],
        "psd":["02_Sc","Image","Rester"],"psb":["02_Sc","Image","Rester"],
        // vector
        "ai":["02_Sc","Image","Vector"],"eps":["02_Sc","Image","Vector"],
        "svg":["02_Sc","Image","Vector"],"pdf":["02_Sc","Image","Vector"],
        // project
        "aep":["02_Sc","Project"],"aet":["02_Sc","Project"],
        // video
        "mp4":["02_Sc","Video","Original"],"mov":["02_Sc","Video","Original"],
        "avi":["02_Sc","Video","Original"],"wmv":["02_Sc","Video","Original"],
        "mkv":["02_Sc","Video","Original"],"mxf":["02_Sc","Video","Original"],
        "r3d":["02_Sc","Video","Original"],"braw":["02_Sc","Video","Original"],
        "m4v":["02_Sc","Video","Original"],"m2v":["02_Sc","Video","Original"],
        "webm":["02_Sc","Video","Original"],
        // audio
        "mp3":["03_Mix","BGM"],"wma":["03_Mix","BGM"],"wav":["03_Mix","BGM"],
        "aif":["03_Mix","BGM"],"aiff":["03_Mix","BGM"],"m4a":["03_Mix","BGM"],
        "flac":["03_Mix","BGM"],"ogg":["03_Mix","BGM"],"aac":["03_Mix","BGM"]
    };

    function decodeName(s) {
        try { return decodeURIComponent(String(s)); } catch(e) { return String(s); }
    }

    // 폴더 선택 (익스텐션과 동일 방식: Windows는 saveDlg, Mac은 selectDialog)
    function browseFolder(title) {
        try {
            var isWindows = ($.os.indexOf("Windows") !== -1);
            if (isWindows) {
                var defaultFile = new File("\uD3F4\uB354\uB97C \uC120\uD0DD\uD558\uACE0 \uC800\uC7A5 \uBC84\uD2BC\uC744 \uB204\uB974\uC138\uC694");
                var saveFile = defaultFile.saveDlg(title || "\uD3F4\uB354 \uC120\uD0DD");
                if (saveFile) return saveFile.parent.fsName;
                return "";
            } else {
                var folder = Folder.selectDialog(title || "Select Folder");
                if (!folder) return "";
                return folder.fsName;
            }
        } catch(e) {
            return "";
        }
    }

    // ========================================================================
    // 폴더 임포트 + 자동분류 (AE 전용)
    // ========================================================================
    function importFolderAndClassify(folderPath) {
        if (IS_PREMIERE) return "error: premiere not supported";
        var proj = app.project;
        var srcFolder = new Folder(folderPath);
        if (!srcFolder.exists) return "error: folder not found";

        // full 트리 먼저 생성 (분류 대상 폴더 보장)
        createFolderTree("full");

        // 트리 내 폴더 경로로 FolderItem 찾기 (대소문자 무시)
        function findFolderByName(targetName, parentFolder) {
            var pf = parentFolder || proj.rootFolder;
            for (var i = 1; i <= proj.numItems; i++) {
                var it = proj.item(i);
                if (it instanceof FolderItem && it.parentFolder === pf
                    && it.name.toLowerCase() === String(targetName).toLowerCase()) return it;
            }
            return null;
        }
        function resolvePath(pathArr) {
            var cur = null;
            for (var i = 0; i < pathArr.length; i++) {
                var found = findFolderByName(pathArr[i], cur || proj.rootFolder);
                if (!found) return null;
                cur = found;
            }
            return cur;
        }

        // 경로 캐시
        var destCache = {};
        function getDest(ext) {
            var p = EXT_MAP[ext];
            if (!p) return null;
            var key = p.join("/");
            if (destCache[key] !== undefined) return destCache[key];
            var f = resolvePath(p);
            destCache[key] = f;
            return f;
        }

        // 재귀로 모든 파일 평평하게 임포트 + 분류
        var stockFolder = null;
        var count = 0;
        function getExt(fn) {
            var d = fn.lastIndexOf(".");
            return d >= 0 ? fn.substring(d+1).toLowerCase() : "";
        }
        function recurse(dir) {
            var items = dir.getFiles();
            var importOpts = new ImportOptions();
            for (var j = 0; j < items.length; j++) {
                var f = items[j];
                if (f instanceof Folder) { recurse(f); continue; }
                if (!(f instanceof File)) continue;
                var ext = getExt(f.name);
                var dest = getDest(ext);
                try {
                    importOpts.file = f;
                    var imported = proj.importFile(importOpts);
                    if (dest) {
                        imported.parentFolder = dest;
                    } else {
                        // 분류 불가 → Stock
                        if (!stockFolder) {
                            stockFolder = findFolderByName("Stock") || proj.items.addFolder("Stock");
                        }
                        imported.parentFolder = stockFolder;
                    }
                    count++;
                } catch(e) {}
            }
        }
        withUndo("Import & Classify", function() { recurse(srcFolder); });
        return "done:" + count;
    }

    // ========================================================================
    // 로컬 폴더트리 생성 (실제 디스크) + 프로젝트 자동 저장
    // ========================================================================
    function createLocalTree(basePath, topName, mode) {
        var baseFolder = new Folder(basePath);
        if (!baseFolder.exists) return "error: base path not found";

        function mk(path) {
            var f = new Folder(path);
            if (!f.exists) f.create();
            return f;
        }
        var rootPath = basePath + "/" + topName;
        var rootObj = mk(rootPath);

        if (mode === "quick") {
            mk(rootPath + "/00_Master");
            mk(rootPath + "/01_Pr");
            mk(rootPath + "/02_Ae");
            var sc = rootPath + "/03_Sc"; mk(sc);
                mk(sc + "/Image"); mk(sc + "/Video");
            mk(rootPath + "/04_Ref");
        } else {
            mk(rootPath + "/00_Master");
            mk(rootPath + "/01_Doc");
            mk(rootPath + "/02_Ref");
            mk(rootPath + "/03_Ae");
            mk(rootPath + "/04_Pr");
            var sc2 = rootPath + "/05_Sc"; mk(sc2);
                var img = sc2 + "/Image"; mk(img);
                    mk(img + "/LOGO"); mk(img + "/Raster"); mk(img + "/Vector");
                mk(sc2 + "/Project");
                var vid = sc2 + "/Video"; mk(vid);
                    mk(vid + "/Original"); mk(vid + "/Render"); mk(vid + "/Source");
            var mix = rootPath + "/06_Mix"; mk(mix);
                mk(mix + "/BGM"); mk(mix + "/Nar"); mk(mix + "/SE");
        }

        // 프로젝트 자동 저장 (Ae/Pr 폴더에)
        var savedPath = "";
        try {
            var ext = IS_PREMIERE ? "prproj" : "aep";
            var tag = IS_PREMIERE ? "pr" : "ae";
            function scoreName(nm) {
                var lo = nm.toLowerCase();
                if (lo === tag) return 3;
                if (new RegExp("[_\\- ]" + tag + "$").test(lo)) return 3;
                if (lo.length >= 2 && lo.substring(lo.length-2) === tag) return 2;
                if (lo.indexOf(tag) !== -1) return 1;
                return 0;
            }
            var subs = rootObj.getFiles(function(f){ return f instanceof Folder; });
            var best = null, bestScore = 0;
            for (var i = 0; i < subs.length; i++) {
                var s = scoreName(decodeName(subs[i].name));
                if (s > bestScore) { bestScore = s; best = subs[i]; }
            }
            var targetF = best || rootObj;
            function uniqueFile(folderPath, baseName, e) {
                var c = new File(folderPath + "/" + baseName + "." + e);
                if (!c.exists) return c;
                var idx = 1;
                while (true) {
                    var c2 = new File(folderPath + "/" + baseName + "_" + idx + "." + e);
                    if (!c2.exists) return c2;
                    idx++; if (idx > 999) return c2;
                }
            }
            if (app.project) {
                var outFile = uniqueFile(targetF.fsName, topName, ext);
                if (IS_PREMIERE) { app.project.saveAs(outFile); }
                else { app.project.save(outFile); }
                savedPath = outFile.fsName;
            }
        } catch(e) {}

        return "done:" + rootObj.fsName + (savedPath ? ("|saved:" + savedPath) : "");
    }

    // ========================================================================
    // 저장: 현재 프로젝트를 로컬 트리의 Ae/Pr 폴더에 다른 이름으로 저장
    // ========================================================================
    // 폴더 안에 태그(ae/pr)로 끝나거나 일치하는 하위 폴더가 있는지
    function hasTagFolder(parentFolder, tag) {
        try {
            if (!parentFolder || !parentFolder.exists) return false;
            var t = String(tag).toLowerCase();
            var re = new RegExp("[_\\- ]" + t + "$");
            var subs = parentFolder.getFiles(function(f){ return f instanceof Folder; });
            for (var i = 0; i < subs.length; i++) {
                var nm = decodeName(subs[i].name).toLowerCase();
                if (nm === t || re.test(nm) || (nm.length >= 2 && nm.substring(nm.length - 2) === t)) return true;
            }
        } catch(e) {}
        return false;
    }

    function saveProjectToTree(treeRootPath, saveName) {
        if (!saveName) return "error: no name";

        var ext = IS_PREMIERE ? "prproj" : "aep";
        var tag = IS_PREMIERE ? "pr" : "ae";

        // 트리 루트: 현재 프로젝트 파일 위치 우선(1up/2up에 Ae/Pr 폴더 있는 쪽), 없으면 넘어온 경로
        var rootF = null;
        try {
            if (app.project && app.project.file) {
                var p1s = app.project.file.parent;
                if (p1s && p1s.exists && hasTagFolder(p1s, tag)) rootF = p1s;
                else if (p1s && p1s.parent && p1s.parent.exists && hasTagFolder(p1s.parent, tag)) rootF = p1s.parent;
                else if (p1s && p1s.exists) rootF = p1s;
            }
        } catch(_) {}
        if (!rootF || !rootF.exists) {
            if (!treeRootPath) return "error: no tree path";
            rootF = new Folder(treeRootPath);
        }
        if (!rootF.exists) return "error: tree not found";
        function scoreName(nm) {
            var lo = nm.toLowerCase();
            if (lo === tag) return 3;
            if (new RegExp("[_\\- ]" + tag + "$").test(lo)) return 3;
            if (lo.length >= 2 && lo.substring(lo.length-2) === tag) return 2;
            if (lo.indexOf(tag) !== -1) return 1;
            return 0;
        }
        var subs = rootF.getFiles(function(f){ return f instanceof Folder; });
        var best = null, bestScore = 0;
        for (var i = 0; i < subs.length; i++) {
            var s = scoreName(decodeName(subs[i].name));
            if (s > bestScore) { bestScore = s; best = subs[i]; }
        }
        var targetF = best || rootF;
        function uniqueFile(folderPath, baseName, e) {
            var c = new File(folderPath + "/" + baseName + "." + e);
            if (!c.exists) return c;
            var idx = 1;
            while (true) {
                var c2 = new File(folderPath + "/" + baseName + "_" + idx + "." + e);
                if (!c2.exists) return c2;
                idx++; if (idx > 999) return c2;
            }
        }
        try {
            var outFile = uniqueFile(targetF.fsName, saveName, ext);
            if (IS_PREMIERE) { app.project.saveAs(outFile); }
            else { app.project.save(outFile); }
            return "done:" + outFile.fsName;
        } catch(e) {
            return "error: " + e.toString();
        }
    }

    // ========================================================================
    // 렌더: 선택 컴프(없으면 전체) → 영문 임시폴더 렌더 → 00_Master 이동 (AE 전용)
    // ========================================================================
    // --- 렌더용 ASCII 임시 루트 (om.file이 멀티바이트 경로를 깨뜨려서, 한글 사용자명에서도 안전) ---
    function _isAsciiPath(p) {
        return /^[\x00-\x7F]*$/.test(String(p));
    }
    function _getAsciiTempRoot() {
        var candidates = [];
        try {
            var envTmp = ($.getenv ? ($.getenv("TEMP") || $.getenv("TMP")) : null);
            if (envTmp) candidates.push(envTmp);
        } catch(_) {}
        var isWin = ($.os.indexOf("Windows") !== -1);
        if (isWin) {
            try {
                var sysDrive = ($.getenv ? $.getenv("SystemDrive") : null) || "C:";
                candidates.push(sysDrive + "\\ProgramData");
                candidates.push(sysDrive + "\\Temp");
                candidates.push(sysDrive + "\\");
            } catch(_) {
                candidates.push("C:\\ProgramData");
                candidates.push("C:\\Temp");
                candidates.push("C:\\");
            }
        } else {
            candidates.push("/tmp");
            candidates.push("/private/tmp");
            candidates.push("/Users/Shared");
        }
        for (var i = 0; i < candidates.length; i++) {
            var base = candidates[i];
            if (!base || !_isAsciiPath(base)) continue;
            try {
                var root = new Folder(base + "/brc_render_temp");
                if (!root.exists) root.create();
                if (root.exists && _isAsciiPath(root.fsName)) {
                    var testF = new File(root.fsName + "/.brc_write_test");
                    var ok = false;
                    try {
                        testF.open("w"); testF.write("1"); testF.close();
                        if (testF.exists) { ok = true; testF.remove(); }
                    } catch(_) { ok = false; }
                    if (ok) return root;
                }
            } catch(_) {}
        }
        try {
            if (Folder.temp && Folder.temp.exists) {
                var ft = new Folder(Folder.temp.fsName + "/brc_render_temp");
                if (!ft.exists) ft.create();
                if (ft.exists) return ft;
            }
        } catch(_) {}
        var ud = new Folder(Folder.userData.fsName + "/brc_render_temp");
        if (!ud.exists) ud.create();
        return ud;
    }

    function renderComps(treeRootPath, autoOutput) {
        if (IS_PREMIERE) return "error: premiere not supported";
        var proj = app.project;
        if (!proj) return "error: no project";

        // _master 폴더 찾기
        function scoreName(nm) {
            var lo = nm.toLowerCase();
            if (lo === "master") return 3;
            if (/[_\- ]master$/.test(lo)) return 3;
            if (lo.indexOf("master") !== -1) return 1;
            return 0;
        }
        function findMasterIn(parentFolder) {
            if (!parentFolder || !parentFolder.exists) return null;
            var subs = parentFolder.getFiles(function(f){ return f instanceof Folder; });
            var best = null, bestScore = 0;
            for (var i = 0; i < subs.length; i++) {
                var s = scoreName(decodeName(subs[i].name));
                if (s > bestScore) { bestScore = s; best = subs[i]; }
            }
            return best;
        }
        var masterFolder = null;
        // 프로젝트 파일 기준 우선: 1단계 위 -> 2단계 위 -> 없으면 00_Master 자동 생성
        if (proj.file) {
            try {
                var p1 = proj.file.parent;
                if (p1) masterFolder = findMasterIn(p1);
                if (!masterFolder && p1 && p1.parent) masterFolder = findMasterIn(p1.parent);
                if (!masterFolder && p1 && p1.exists) {
                    var newMaster = new Folder(p1.fsName + "/00_Master");
                    try { if (!newMaster.exists) newMaster.create(); if (newMaster.exists) masterFolder = newMaster; } catch(_) {}
                }
            } catch(_) {}
        }
        if (!masterFolder && treeRootPath) {
            masterFolder = findMasterIn(new Folder(treeRootPath));
        }

        // 렌더 대상 컴프
        var comps = [];
        var sel = proj.selection;
        if (sel && sel.length) {
            for (var si = 0; si < sel.length; si++) {
                if (sel[si] instanceof CompItem) comps.push(sel[si]);
            }
        }
        if (!comps.length) {
            for (var pi = 1; pi <= proj.numItems; pi++) {
                var it = proj.item(pi);
                if (it instanceof CompItem) comps.push(it);
            }
        }
        if (!comps.length) return "error: no comps";

        var rq = proj.renderQueue;

        if (!autoOutput) {
            // 큐에 추가만 (기존 항목 렌더 제외)
            for (var qi = 1; qi <= rq.numItems; qi++) {
                try { rq.item(qi).render = false; } catch(_) {}
            }
            var added = 0;
            for (var ci = 0; ci < comps.length; ci++) {
                try { var r = rq.items.add(comps[ci]); r.render = true; added++; } catch(_) {}
            }
            return "queued:" + added;
        }

        // 자동 출력 ON: 영문 임시폴더 렌더 → 00_Master 이동
        if (!masterFolder || !masterFolder.exists) return "error: no master folder";
        var tempRoot = _getAsciiTempRoot();
        if (!tempRoot || !tempRoot.exists) return "error: no temp folder";
        if (!_isAsciiPath(tempRoot.fsName)) return "error: temp path not ascii - " + tempRoot.fsName;
        var tempFolder = new Folder(tempRoot.fsName + "/r" + (new Date()).getTime());
        if (!tempFolder.exists) tempFolder.create();

        for (var qx = 1; qx <= rq.numItems; qx++) {
            try { rq.item(qx).render = false; } catch(_) {}
        }
        var jobs = [];
        for (var c2 = 0; c2 < comps.length; c2++) {
            try {
                var rqItem = rq.items.add(comps[c2]);
                rqItem.render = true;
                var om = rqItem.outputModule(1);
                var tempName = "render_" + c2 + "_";  // 끝 구분자: render_1 이 render_10 접두사가 되는 충돌 방지
                om.file = new File(tempFolder.fsName + "/" + tempName);
                jobs.push({ tempBase: tempName, jobIndex: c2, compName: comps[c2].name });
            } catch(_) {}
        }
        if (!jobs.length) { try { tempFolder.remove(); } catch(_){} return "error: nothing added"; }

        try { rq.render(); } catch(rerr) { return "error: render failed - " + rerr.toString(); }

        var moved = 0;
        var produced = tempFolder.getFiles();
        for (var p = 0; p < produced.length; p++) {
            var pf = produced[p];
            if (!(pf instanceof File)) continue;
            var pfName = decodeName(pf.name);
            var idxMatch = pfName.match(/^render_(\d+)_/);  // render_1_ 과 render_10_ 혼동 방지
            if (!idxMatch) continue;
            var jobIdx = parseInt(idxMatch[1], 10);
            for (var j = 0; j < jobs.length; j++) {
                if (jobs[j].jobIndex === jobIdx) {
                    var ex = "";
                    var dot = pfName.lastIndexOf(".");
                    if (dot >= 0) ex = pfName.substring(dot);
                    var destFile = new File(masterFolder.fsName + "/" + jobs[j].compName + ex);
                    if (destFile.exists) {
                        var idx = 1;
                        while (true) {
                            var alt = new File(masterFolder.fsName + "/" + jobs[j].compName + "_" + idx + ex);
                            if (!alt.exists) { destFile = alt; break; }
                            idx++; if (idx > 999) break;
                        }
                    }
                    try { if (pf.copy(destFile)) moved++; } catch(_) {}
                    break;
                }
            }
        }
        try {
            var leftover = tempFolder.getFiles();
            for (var lf = 0; lf < leftover.length; lf++) { try { leftover[lf].remove(); } catch(_) {} }
            tempFolder.remove();
        } catch(_) {}
        try { masterFolder.execute(); } catch(_) {}
        return "rendered:" + moved;
    }

    // ========================================================================
    // 설정 / 도움말 창
    // ========================================================================
    function showSettingsDialog(editFont, onSettingsSaved) {
        var dlg = new Window("dialog", "\uC124\uC815 / \uB3C4\uC6C0\uB9D0");
        dlg.orientation = "column";
        dlg.alignChildren = ["fill", "top"];
        dlg.spacing = 8;
        dlg.margins = 14;
        dlg.preferredSize.width = 380;

        // 한 줄씩 statictext 추가 (multiline wrap으로 인한 잘림 방지)
        function addLines(parent, lines) {
            for (var i = 0; i < lines.length; i++) {
                var st = parent.add("statictext", undefined, lines[i]);
                st.alignment = ["left", "top"];
                if (editFont) { try { st.graphics.font = editFont; } catch(e) {} }
            }
        }

        // ── 사용 가이드 ──
        var guidePanel = dlg.add("panel", undefined, "\uC0AC\uC6A9 \uAC00\uC774\uB4DC");
        guidePanel.orientation = "column";
        guidePanel.alignChildren = ["left", "top"];
        guidePanel.spacing = 5;
        guidePanel.margins = 12;
        addLines(guidePanel, [
            "\u2022 \uC774\uB984: \uB0A0\uC9DC_\uAD11\uACE0\uC8FC_\uCEA0\uD398\uC778_\uD398\uC774\uC9C0_\uC791\uC5C5\uB0B4\uC6A9_",
            "       \uD574\uC0C1\uB3C4_\uC791\uC5C5\uC790_@\uC791\uC5C5\uC885\uB958_\uC791\uC5C5\uAD6C\uBD84",
            "\u2022 \uAC01 \uD544\uB4DC \u27F3 : \uD574\uB2F9 \uD544\uB4DC\uB9CC \uC120\uD0DD \uCEF4\uD504\uC5D0 \uAC1C\uBCC4 \uC801\uC6A9",
            "\u2022 \uCEA0\uD398\uC778/\uD398\uC774\uC9C0/\uC791\uC5C5\uB0B4\uC6A9 \u27F3 : \uAC19\uC740 \uAC12 \uB2E4\uC2DC \uB204\uB974\uBA74 \uB05D \uC22B\uC790 +1",
            "\u2022 \uC774\uB984\uBCC0\uACBD : \uBAA8\uB4E0 \uD544\uB4DC \uC870\uD569\uD574 \uC774\uB984 \uC77C\uAD04 \uBCC0\uACBD",
            "\u2022 \uBD88\uB7EC\uC624\uAE30 : \uC120\uD0DD \uCEF4\uD504 \uC774\uB984\uC744 \uAC01 \uD544\uB4DC\uB85C \uBD84\uC11D",
            "\u2022 \uC120\uD0DD\uBCC0\uACBD : \uCC3E\uC744 \uD14D\uC2A4\uD2B8 \u2192 \uBC14\uAFC0 \uD14D\uC2A4\uD2B8",
            "\u2022 + : \uD504\uB85C\uC81D\uD2B8 \uD3F4\uB354\uD2B8\uB9AC \uC0DD\uC131 (Shift: \uAC04\uB2E8\uD615)",
            "\u2022 \uBC84\uD2BC\uC5D0 \uB9C8\uC6B0\uC2A4\uB97C \uC62C\uB9AC\uBA74 \uC124\uBA85(\uD234\uD301)\uC774 \uB098\uC635\uB2C8\uB2E4"
        ]);

        // ── 도구 버튼 설명 ──
        var toolPanel = dlg.add("panel", undefined, "\uD558\uB2E8 \uB3C4\uAD6C \uBC84\uD2BC");
        toolPanel.orientation = "column";
        toolPanel.alignChildren = ["left", "top"];
        toolPanel.spacing = 5;
        toolPanel.margins = 12;
        addLines(toolPanel, [
            "\u2913 \uC800\uC7A5 : \uD504\uB85C\uC81D\uD2B8\uAC00 \uC18D\uD55C \uD2B8\uB9AC\uC758 Ae/Pr \uD3F4\uB354\uC5D0 \uB2E4\uB978 \uC774\uB984\uC73C\uB85C \uC800\uC7A5",
            "\u2912 \uC784\uD3EC\uD2B8 : \uD3F4\uB354 \uD30C\uC77C\uC744 \uD655\uC7A5\uC790\uBCC4 \uC790\uB3D9 \uBD84\uB958 (AE \uC804\uC6A9)",
            "\u25B6 \uB80C\uB354 : \uC120\uD0DD(\uC5C6\uC73C\uBA74 \uC804\uCCB4) \uCEF4\uD504\uB97C \uB80C\uB354 \uD050\uC5D0 \uCD94\uAC00",
            "       (Shift: \uC989\uC2DC \uB80C\uB354 \uD6C4 00_Master \uC800\uC7A5, AE \uC804\uC6A9)",
            "\u2630 \uB85C\uCEEC\uD2B8\uB9AC : \uB514\uC2A4\uD06C\uC5D0 \uD3F4\uB354\uD2B8\uB9AC \uC0DD\uC131 + \uC790\uB3D9 \uC800\uC7A5",
            "       (Shift: \uAC04\uB2E8\uD615)"
        ]);

        // ── 해상도 프리셋 편집 ──
        var resPanel = dlg.add("panel", undefined, "\uD574\uC0C1\uB3C4 \uD504\uB9AC\uC14B");
        resPanel.orientation = "column";
        resPanel.alignChildren = ["fill", "top"];
        resPanel.spacing = 5;
        resPanel.margins = 12;
        var resHelp = resPanel.add("statictext", undefined, "\uD55C \uC904\uC5D0 \uD558\uB098\uC529 (\uC608: 1920x1080 (16:9))");
        if (editFont) { try { resHelp.graphics.font = editFont; } catch(e) {} }
        var resBox = resPanel.add("edittext", undefined, "", { multiline: true });
        resBox.preferredSize.height = 110;
        if (editFont) { try { resBox.graphics.font = editFont; } catch(e) {} }
        // 현재 프리셋(None 제외)을 줄 단위로 채움
        (function(){
            var cur = getSetting("resPresets", null);
            var list = (cur && cur.length) ? cur : RES_LIST.slice(1); // None 제외
            resBox.text = list.join("\n");
        })();

        // ── 기본 경로 ──
        var pathPanel = dlg.add("panel", undefined, "\uAE30\uBCF8 \uACBD\uB85C (\uBE44\uC6CC\uB450\uBA74 \uB9E4\uBC88 \uC120\uD0DD)");
        pathPanel.orientation = "column";
        pathPanel.alignChildren = ["fill", "top"];
        pathPanel.spacing = 6;
        pathPanel.margins = 12;

        function makePathRow(labelText, settingKey) {
            var row = pathPanel.add("group");
            row.orientation = "row";
            row.alignChildren = ["fill", "center"];
            row.spacing = 4;
            var lb = row.add("statictext", undefined, labelText);
            lb.preferredSize.width = 64;
            if (editFont) { try { lb.graphics.font = editFont; } catch(e) {} }
            var tf = row.add("edittext", undefined, getSetting(settingKey, "") || "");
            tf.alignment = ["fill", "center"];
            if (editFont) { try { tf.graphics.font = editFont; } catch(e) {} }
            var br = row.add("button", undefined, "\u2026");
            br.helpTip = "\uD3F4\uB354 \uCC3E\uC544\uBCF4\uAE30";
            br.preferredSize.width = 28;
            var cl = row.add("button", undefined, "\u2715");
            cl.helpTip = "\uC9C0\uC6B0\uAE30";
            cl.preferredSize.width = 24;
            br.onClick = function() {
                var p = browseFolder(labelText + " \uC120\uD0DD");
                if (p) tf.text = p;
            };
            cl.onClick = function() { tf.text = ""; };
            return tf;
        }
        var importPathTF   = makePathRow("\uC784\uD3EC\uD2B8", "importPath");
        var localTreePathTF = makePathRow("\uB85C\uCEEC\uD2B8\uB9AC", "localTreePath");

        // ── 닫기 ──
        var btnRow = dlg.add("group");
        btnRow.alignment = ["fill", "center"];
        btnRow.alignChildren = ["fill", "center"];
        btnRow.spacing = 4;
        var saveSetBtn = btnRow.add("button", undefined, "\uC800\uC7A5", { name: "ok" });
        saveSetBtn.alignment = ["fill", "center"];
        var cancelBtn = btnRow.add("button", undefined, "\uCDE8\uC18C", { name: "cancel" });
        cancelBtn.alignment = ["fill", "center"];

        saveSetBtn.onClick = function() {
            // 해상도 프리셋 파싱 (빈 줄 제거)
            var raw = String(resBox.text).split(/[\r\n]+/);
            var presets = [];
            for (var i = 0; i < raw.length; i++) {
                var line = raw[i].replace(/^\s+|\s+$/g, "");
                if (line) presets.push(line);
            }
            var s = loadSettings();
            s.resPresets = presets;
            s.importPath = String(importPathTF.text).replace(/^\s+|\s+$/g, "");
            s.localTreePath = String(localTreePathTF.text).replace(/^\s+|\s+$/g, "");
            saveSettings(s);
            if (typeof onSettingsSaved === "function") onSettingsSaved(presets);
            dlg.close();
        };

        dlg.layout.layout(true);
        dlg.show();
    }

    // ========================================================================
    // ========================================================================
    function parseCompName(name) {
        var result = {
            client: "", campaign: "", page: "", task: "",
            resolution: "", worker: "", jobKind: "", workType: ""
        };
        if (!name) return result;

        var parts = smartSplit(name);
        var generic = [];

        var workerIdx = -1;
        for (var w = 1; w < parts.length; w++) {
            if (/^@/.test(parts[w]) && isJobKind(parts[w]) &&
                /^[A-Z]{2,5}$/.test(parts[w-1])) {
                workerIdx = w - 1;
                break;
            }
        }

        for (var i = 0; i < parts.length; i++) {
            var p = parts[i];
            if (!p) continue;
            if (isDate(p)) continue;
            if (isResolution(p))      { result.resolution = p; continue; }
            if (isWorkType(p)) {
                result.workType = /^retuch\d+$/.test(p) ? "retuch1" : p;
                continue;
            }
            if (/^@/.test(p) && isJobKind(p)) { result.jobKind = p; continue; }
            if (/^\d+p$/.test(p))     { result.page = p.replace(/p$/, ""); continue; }
            if (i === workerIdx)      { result.worker = p; continue; }
            generic.push(p);
        }

        if (generic.length > 0) result.client   = generic[0];
        if (generic.length > 1) result.campaign = generic[1];
        if (generic.length > 2) result.task     = generic.slice(2).join("_");

        return result;
    }

    // ========================================================================
    // ========================================================================
    function buildUI(thisObj) {
        var isPanel = (typeof Panel !== "undefined" && thisObj instanceof Panel);
        var win = isPanel
            ? thisObj
            : new Window("palette", "Batch Rename", undefined, {resizeable: true});

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        var LABEL_W = 52;
        var BTN_W   = 22;
        var CTRL_H  = 20;
        var GAP     = 2;
        var ROW_V   = 1;
        var SEP_V   = 5;
        var REP_FW  = 70;
        var ARR_W   = 12;

        var savedWorker = loadWorker();

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        function makeKoreanFont(size) {
            var candidates = [
                "Pretendard",
                "Pretendard Variable",
                "Malgun Gothic",
                "\uB9D1\uC740 \uACE0\uB515",
                "Apple SD Gothic Neo",
                "Noto Sans CJK KR",
                "Nanum Gothic"
            ];
            for (var i = 0; i < candidates.length; i++) {
                try {
                    var f = ScriptUI.newFont(candidates[i], ScriptUI.FontStyle.REGULAR, size);
                    if (f) return f;
                } catch (e) {}
            }
            try {
                return ScriptUI.newFont("dialog", ScriptUI.FontStyle.REGULAR, size);
            } catch (e) {}
            return null;
        }
        var EDIT_FONT = makeKoreanFont(14);

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        win.orientation   = "column";
        win.alignChildren = ["fill", "fill"];
        win.spacing       = 0;
        win.margins       = [3, 3, 3, 3];

        var ui = win.add("group");
        ui.orientation   = "column";
        ui.alignChildren = ["fill", "top"];
        ui.alignment     = ["fill", "top"];
        ui.spacing       = 0;
        ui.margins       = [4, 1, 4, 4];

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        function makeRow(parent, labelText, kind, options) {
            options = options || {};
            var withBtn = !!options.btn;

            var row = parent.add("group");
            row.orientation   = "row";
            row.alignChildren = ["fill", "center"];
            row.alignment     = ["fill", "center"];
            row.spacing       = GAP;
            row.margins = [2, ROW_V, 2, ROW_V];

            var lbl = row.add("statictext", undefined, labelText);
            lbl.preferredSize.width = LABEL_W;
            lbl.alignment = ["left", "center"];

            var ctrl;
            if (kind === "edit") {
                ctrl = row.add("edittext", undefined, options.value || "");
                if (EDIT_FONT) {
                    try { ctrl.graphics.font = EDIT_FONT; } catch (e) {}
                }
            } else if (kind === "drop") {
                ctrl = row.add("dropdownlist", undefined, options.items || []);
                if (ctrl.items && ctrl.items.length > 0) ctrl.selection = 0;
                if (EDIT_FONT) {
                    try { ctrl.graphics.font = EDIT_FONT; } catch (e) {}
                }
            }
            ctrl.preferredSize.height = CTRL_H;
            ctrl.alignment = ["fill", "center"];

            var btn = null;
            if (withBtn) {
                btn = row.add("button", undefined, "\u27F3");
                btn.helpTip = labelText + " \uC801\uC6A9";
                btn.preferredSize = [BTN_W, CTRL_H];
                btn.alignment = ["right", "center"];
            }

            return { row: row, ctrl: ctrl, btn: btn };
        }

        function makeSeparator(parent) {
            var g = parent.add("group");
            g.orientation = "row";
            g.alignChildren = ["fill", "center"];
            g.alignment = ["fill", "center"];
            g.margins = [2, SEP_V, 2, SEP_V];
            g.spacing = 0;
            g.preferredSize.height = 1;
            g.onDraw = function () {
                var w = g.size[0];
                if (!w) return;
                var gfx = g.graphics;
                var pen = gfx.newPen(gfx.PenType.SOLID_COLOR, [0.3, 0.3, 0.3, 1], 1);
                gfx.newPath();
                gfx.moveTo(0, 0);
                gfx.lineTo(w, 0);
                gfx.strokePath(pen);
            };
        }

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        var rDate     = makeRow(ui, "\uB0A0\uC9DC",    "edit", { value: getTodayYYMMDD(), btn: true });
        var rClient   = makeRow(ui, "\uAD11\uACE0\uC8FC\uBA85", "edit", { value: "", btn: true });
        var rCampaign = makeRow(ui, "\uCEA0\uD398\uC778\uBA85", "edit", { value: "", btn: true });
        var rPage     = makeRow(ui, "\uD398\uC774\uC9C0",  "edit", { value: "", btn: true });
        var rTask     = makeRow(ui, "\uC791\uC5C5\uB0B4\uC6A9", "edit", { value: "", btn: true });
        // 저장된 해상도 프리셋이 있으면 반영 (None + 프리셋)
        var resItems = (function(){
            var cur = getSetting("resPresets", null);
            if (cur && cur.length) {
                var arr = ["None"];
                for (var i = 0; i < cur.length; i++) arr.push(cur[i]);
                return arr;
            }
            return RES_LIST;
        })();
        var rRes      = makeRow(ui, "\uD574\uC0C1\uB3C4",  "drop", { items: resItems, btn: true });

        var rWorker   = makeRow(ui, "\uC791\uC5C5\uC790",  "edit", { value: savedWorker, btn: true });
        var wf = rWorker.ctrl;
        wf.onChange = function () {
            var v = trimStr(wf.text).toUpperCase();
            wf.text = v;
            saveWorker(v);
        };
        wf.onDeactivate = function () {
            var v = trimStr(wf.text).toUpperCase();
            wf.text = v;
            saveWorker(v);
        };

        var rJobKind = makeRow(ui, "\uC791\uC5C5\uC885\uB958", "drop", { items: JOBKIND_LIST, btn: true });
        var rType    = makeRow(ui, "\uC791\uC5C5\uAD6C\uBD84", "drop", { items: TYPE_LIST, btn: true });

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        var repRow = ui.add("group");
        repRow.orientation = "row";
        repRow.alignChildren = ["fill", "center"];
        repRow.alignment = ["fill", "center"];
        repRow.spacing = GAP;
        repRow.margins = [2, ROW_V, 2, ROW_V];

        var repLbl = repRow.add("statictext", undefined, "\uC120\uD0DD\uBCC0\uACBD");
        repLbl.preferredSize.width = LABEL_W;
        repLbl.alignment = ["left", "center"];

        var fromF = repRow.add("edittext", undefined, "");
        fromF.preferredSize.height = CTRL_H;
        fromF.alignment = ["fill", "center"];
        if (EDIT_FONT) { try { fromF.graphics.font = EDIT_FONT; } catch (e) {} }

        var toF = repRow.add("edittext", undefined, "");
        toF.preferredSize.height = CTRL_H;
        toF.alignment = ["fill", "center"];
        if (EDIT_FONT) { try { toF.graphics.font = EDIT_FONT; } catch (e) {} }

        var repBtn = repRow.add("button", undefined, "\u27F3");
        repBtn.helpTip = "\uC774\uB984 \uC548\uC758 \uD2B9\uC815 \uBB38\uC790\uC5F4 \uCE58\uD658 (from -> to)";
        repBtn.preferredSize = [BTN_W, CTRL_H];
        repBtn.alignment = ["right", "center"];

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        var preLoadGap = ui.add("group");
        preLoadGap.alignment = ["fill", "center"];
        preLoadGap.preferredSize.height = 4;
        preLoadGap.margins = 0;
        preLoadGap.spacing = 0;

        var loadRow = ui.add("group");
        loadRow.orientation = "row";
        loadRow.alignment = ["fill", "center"];
        loadRow.alignChildren = ["fill", "center"];
        loadRow.spacing = GAP;
        loadRow.margins = [2, 0, 2, 0];

        var loadBtn = loadRow.add("button", undefined, "\uBD88\uB7EC\uC624\uAE30");
        loadBtn.helpTip = "\uC120\uD0DD\uD55C \uCEF4\uD504 \uC774\uB984\uC744 \uD544\uB4DC\uB85C \uBD84\uD574\uD574 \uBD88\uB7EC\uC624\uAE30";
        loadBtn.alignment = ["fill", "center"];
        loadBtn.preferredSize.height = CTRL_H + 2;

        var clearBtn = loadRow.add("button", undefined, "\u2715");
        clearBtn.helpTip = "\uC785\uB825 \uD544\uB4DC \uCD08\uAE30\uD654 (\uB0A0\uC9DC/\uC791\uC5C5\uC790\uB294 \uC720\uC9C0)";
        clearBtn.preferredSize = [BTN_W, CTRL_H + 2];
        clearBtn.alignment = ["right", "center"];

        var loadGap = ui.add("group");
        loadGap.alignment = ["fill", "center"];
        loadGap.preferredSize.height = 2;
        loadGap.margins = 0;
        loadGap.spacing = 0;

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        var spaceG = ui.add("group");
        spaceG.alignment = ["fill", "center"];
        spaceG.preferredSize.height = 2;
        spaceG.margins = 0;
        spaceG.spacing = 0;

        var applyBtnRow = ui.add("group");
        applyBtnRow.orientation = "row";
        applyBtnRow.alignment = ["fill", "center"];
        applyBtnRow.alignChildren = ["fill", "center"];
        applyBtnRow.spacing = GAP;
        applyBtnRow.margins = [2, 0, 2, 0];

        var applyBtn = applyBtnRow.add("button", undefined, "\uC774\uB984\uBCC0\uACBD");
        applyBtn.helpTip = "\uD544\uB4DC \uC870\uD569\uC73C\uB85C \uC120\uD0DD\uD55C \uCEF4\uD504 \uC774\uB984 \uC77C\uAD04 \uBCC0\uACBD";
        applyBtn.alignment = ["fill", "center"];
        applyBtn.preferredSize.height = CTRL_H + 4;

        var folderBtn = applyBtnRow.add("button", undefined, "+");
        folderBtn.helpTip = "\uD504\uB85C\uC81D\uD2B8 \uD3F4\uB354\uD2B8\uB9AC \uC0DD\uC131 + \uC18C\uC2A4 \uC815\uB9AC (Shift+\uD074\uB9AD: \uAC04\uB2E8 \uD2B8\uB9AC)";
        folderBtn.preferredSize = [BTN_W, CTRL_H + 4];
        folderBtn.alignment = ["right", "center"];

        // ── 도구 버튼 행 (저장 / 임포트 / 렌더 / 로컬트리) ──
        var toolGap = ui.add("group");
        toolGap.alignment = ["fill", "center"];
        toolGap.preferredSize.height = 2;
        toolGap.margins = 0; toolGap.spacing = 0;

        var toolRow = ui.add("group");
        toolRow.orientation = "row";
        toolRow.alignment = ["fill", "center"];
        toolRow.alignChildren = ["fill", "center"];
        toolRow.spacing = GAP;
        toolRow.margins = [2, 0, 2, 0];

        var saveBtn = toolRow.add("button", undefined, "\u2913");
        saveBtn.helpTip = "\uD504\uB85C\uC81D\uD2B8\uB97C \uD2B8\uB9AC\uC758 Ae/Pr \uD3F4\uB354\uC5D0 \uC800\uC7A5";
        saveBtn.alignment = ["fill", "center"];
        saveBtn.preferredSize.height = CTRL_H + 2;
        var importBtn = toolRow.add("button", undefined, "\u2912");
        importBtn.helpTip = "\uD3F4\uB354\uB97C 02_Sc\uB85C \uBD84\uB958\uD574 \uC784\uD3EC\uD2B8 (AE \uC804\uC6A9)";
        importBtn.alignment = ["fill", "center"];
        importBtn.preferredSize.height = CTRL_H + 2;
        var renderBtn = toolRow.add("button", undefined, "\u25B6");
        renderBtn.helpTip = "\uB80C\uB354 \uD050 \uCD94\uAC00 (Shift+\uD074\uB9AD: \uC989\uC2DC \uB80C\uB354 \uD6C4 00_Master, AE \uC804\uC6A9)";
        renderBtn.alignment = ["fill", "center"];
        renderBtn.preferredSize.height = CTRL_H + 2;
        var localTreeBtn = toolRow.add("button", undefined, "\u2630");
        localTreeBtn.helpTip = "\uB514\uC2A4\uD06C\uC5D0 \uD3F4\uB354\uD2B8\uB9AC \uC0DD\uC131 + \uC790\uB3D9 \uC800\uC7A5 (Shift+\uD074\uB9AD: \uAC04\uB2E8 \uD2B8\uB9AC)";
        localTreeBtn.alignment = ["fill", "center"];
        localTreeBtn.preferredSize.height = CTRL_H + 2;
        var settingsBtn = toolRow.add("button", undefined, "\u2699");
        settingsBtn.helpTip = "\uC124\uC815 (\uACBD\uB85C/\uD574\uC0C1\uB3C4 \uD504\uB9AC\uC14B)";
        settingsBtn.preferredSize = [BTN_W, CTRL_H + 2];
        settingsBtn.alignment = ["right", "center"];

        var btnBottomGap = ui.add("group");
        btnBottomGap.alignment = ["fill", "center"];
        btnBottomGap.preferredSize.height = 4;
        btnBottomGap.margins = 0;
        btnBottomGap.spacing = 0;

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        var bottomFill = win.add("group");
        bottomFill.alignment = ["fill", "fill"];
        bottomFill.preferredSize = [0, 0];

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        function buildName() {
            var parts = [];
            var date  = sanitize(trimStr(rDate.ctrl.text));
            var cli   = sanitize(trimStr(rClient.ctrl.text));
            var cmp   = sanitize(trimStr(rCampaign.ctrl.text));
            var page  = trimStr(rPage.ctrl.text).replace(/[^0-9]/g, "");
            var task  = sanitize(trimStr(rTask.ctrl.text));
            var res   = ddText(rRes.ctrl, "None");
            var resVal = res !== "None" ? resCode(res) : "None";
            var work  = trimStr(wf.text).toUpperCase();
            var jk    = jobKindCode(ddText(rJobKind.ctrl, "None"));
            var ty    = ddText(rType.ctrl, "None");

            if (date)         parts.push(date);
            if (cli)          parts.push(cli);
            if (cmp)          parts.push(cmp);
            if (page)         parts.push(page + "p");
            if (task)         parts.push(task);
            if (resVal !== "None")  parts.push(resVal);
            if (work)         parts.push(work);
            if (jk !== "None")   parts.push(jk);
            if (ty !== "None")   parts.push(ty);

            return parts.join("_");
        }

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────

        function incrementText(text, isPage) {
            text = trimStr(text);
            if (!text) return text;
            if (isPage) {
                var num = parseInt(text.replace(/[^0-9]/g, ""), 10);
                return isNaN(num) ? text : String(num + 1);
            }
            var m = text.match(/^(.*?)_(\d+)$/);
            if (m) {
                return m[1] + "_" + (parseInt(m[2], 10) + 1);
            }
            return text + "_1";
        }

        rDate.btn.onClick = function () {
            var v = sanitize(trimStr(rDate.ctrl.text)); if (!v) return;
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Apply Date", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyDateTo(getItemName(items[i]), v));
            });
        };
        rDate.ctrl.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") rDate.btn.notify();
        });

        rClient.btn.onClick = function () {
            var v = sanitize(trimStr(rClient.ctrl.text)); if (!v) return;
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Apply Client", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyGenericTo(getItemName(items[i]), v, 0));
            });
        };
        rClient.ctrl.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") rClient.btn.notify();
        });

        var lastCampaign = "";
        var applyCampaign = function(increment) {
            var v = sanitize(trimStr(rCampaign.ctrl.text)); if (!v) return;
            var items = getSelectedItems(); if (!items.length) return;
            var applyVal;
            if (increment && lastCampaign === v) {
                applyVal = incrementText(v, false);
                rCampaign.ctrl.text = applyVal;
                lastCampaign = applyVal;
            } else {
                applyVal = v;
                lastCampaign = v;
            }
            withUndo("Apply Campaign", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyGenericTo(getItemName(items[i]), applyVal, 1));
            });
        };
        rCampaign.btn.onClick = function () { applyCampaign(true); };
        rCampaign.ctrl.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") applyCampaign(true);
        });

        var lastPage = "";
        var applyPage = function(increment) {
            var v = trimStr(rPage.ctrl.text).replace(/[^0-9]/g, ""); if (!v) return;
            var items = getSelectedItems(); if (!items.length) return;
            var applyVal;
            if (increment && lastPage === v) {
                applyVal = incrementText(v, true);
                rPage.ctrl.text = applyVal;
                lastPage = applyVal;
            } else {
                applyVal = v;
                lastPage = v;
            }
            withUndo("Apply Page", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyPageTo(getItemName(items[i]), applyVal));
            });
        };
        rPage.btn.onClick = function () { applyPage(true); };
        rPage.ctrl.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") applyPage(true);
        });

        var lastTask = "";
        var applyTask = function(increment) {
            var v = sanitize(trimStr(rTask.ctrl.text)); if (!v) return;
            var items = getSelectedItems(); if (!items.length) return;
            var applyVal, oldVal;
            if (increment && lastTask === v) {
                applyVal = incrementText(v, false);
                oldVal = v;
                rTask.ctrl.text = applyVal;
                lastTask = applyVal;
            } else {
                applyVal = v;
                oldVal = items.length ? parseCompName(getItemName(items[0])).task : "";
                lastTask = v;
            }
            withUndo("Apply Task", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyTaskTo(getItemName(items[i]), oldVal, applyVal));
            });
        };
        rTask.btn.onClick = function () { applyTask(true); };
        rTask.ctrl.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") applyTask(true);
        });

        rWorker.btn.onClick = function () {
            var v = trimStr(wf.text).toUpperCase(); if (!v) return;
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Apply Worker", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyWorkerTo(getItemName(items[i]), v));
            });
        };
        wf.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") rWorker.btn.notify();
        });
        rRes.btn.onClick = function () {
            if (ScriptUI.environment.keyboardState.shiftKey) {
                var result = prompt("\uD574\uC0C1\uB3C4 \uC9C1\uC811 \uC785\uB825 (ex: 2560x1440)", "");
                if (result && trimStr(result)) {
                    var code = trimStr(result).replace(/X/g, "x");
                    var items = getSelectedItems(); if (!items.length) return;
                    withUndo("Apply Resolution", function () {
                        for (var i = 0; i < items.length; i++)
                            setItemName(items[i], applyResTo(getItemName(items[i]), code));
                    });
                }
                return;
            }
            var v = ddText(rRes.ctrl, "None"); if (v === "None") return;
            var code = resCode(v);
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Apply Resolution", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyResTo(getItemName(items[i]), code));
            });
        };
        rJobKind.btn.onClick = function () {
            var v = ddText(rJobKind.ctrl, "None"); if (v === "None") return;
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Apply Job Kind", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyJobKindTo(getItemName(items[i]), v));
            });
        };
        rType.btn.onClick = function () {
            var v = ddText(rType.ctrl, "None"); if (v === "None") return;
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Apply Work Type", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], applyTypeTo(getItemName(items[i]), v));
            });
        };
        repBtn.onClick = function () {
            var a = trimStr(fromF.text); if (!a) return;
            var b = trimStr(toF.text);
            var items = getSelectedItems(); if (!items.length) return;
            withUndo("Replace Text", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], String(getItemName(items[i])).split(a).join(b));
            });
        };
        fromF.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") toF.active = true;
        });
        toF.addEventListener("keydown", function(e) {
            if (e.keyName === "Enter") repBtn.notify();
        });
        clearBtn.onClick = function () {
            rClient.ctrl.text   = "";
            rCampaign.ctrl.text = "";
            rPage.ctrl.text     = "";
            rTask.ctrl.text     = "";
            rRes.ctrl.selection  = 0;   // None
            rJobKind.ctrl.selection = 0; // None
            rType.ctrl.selection = 0;    // None
            fromF.text = "";
            toF.text   = "";
        };

        applyBtn.onClick = function () {
            var items = getSelectedItems(); if (!items.length) return;
            var n = buildName(); if (!n) return;
            withUndo("Batch Rename", function () {
                for (var i = 0; i < items.length; i++)
                    setItemName(items[i], n);
            });
        };

        // ─────────────────────────────────────────────────────────────────
        settingsBtn.onClick = function () {
            showSettingsDialog(EDIT_FONT, function(presets) {
                // 해상도 드롭다운 갱신: 현재 선택 보존 시도
                var prevSel = rRes.ctrl.selection ? String(rRes.ctrl.selection.text) : null;
                rRes.ctrl.removeAll();
                rRes.ctrl.add("item", "None");
                for (var i = 0; i < presets.length; i++) rRes.ctrl.add("item", presets[i]);
                // 이전 선택 복원, 없으면 None
                var restored = false;
                if (prevSel) {
                    for (var j = 0; j < rRes.ctrl.items.length; j++) {
                        if (String(rRes.ctrl.items[j].text) === prevSel) {
                            rRes.ctrl.selection = j; restored = true; break;
                        }
                    }
                }
                if (!restored) rRes.ctrl.selection = 0;
            });
        };

        // ─────────────────────────────────────────────────────────────────
        folderBtn.onClick = function () {
            var isQuick = ScriptUI.environment.keyboardState.shiftKey;
            createFolderTree(isQuick ? "quick" : "full");
        };

        // ── 마지막 생성한 로컬 트리 루트 경로 (저장/렌더 출력 위치 기준) ──
        var lastTreePath = null;

        // 로컬 폴더트리 생성 (실제 디스크) + 자동 저장
        localTreeBtn.onClick = function () {
            if (IS_PREMIERE && !app.project) { alert("프로젝트를 먼저 열어주세요."); return; }
            // 설정에 기본 위치가 있으면 사용, 없으면 탐색기로 선택
            var basePath = getSetting("localTreePath", "");
            if (!basePath) {
                basePath = browseFolder("\uD3F4\uB354\uD2B8\uB9AC\uB97C \uB9CC\uB4E4 \uC704\uCE58 \uC120\uD0DD");
                if (!basePath) return;
            }
            var isQuick = ScriptUI.environment.keyboardState.shiftKey;
            // 최상위 폴더명: 현재 프로젝트명(확장자 제외) 기본값
            var defName = "Project";
            try {
                if (app.project && app.project.file) {
                    var nm = decodeName(app.project.file.name);
                    defName = nm.replace(/\.[^.]+$/, "");
                }
            } catch(e) {}
            var topName = prompt("\uCD5C\uC0C1\uC704 \uD3F4\uB354 \uC774\uB984:", defName);
            if (!topName) return;
            var r = createLocalTree(basePath, topName, isQuick ? "quick" : "full");
            if (r.indexOf("error") === 0) { alert("\uC0DD\uC131 \uC2E4\uD328: " + r); return; }
            var rootPath = r.substring(5);
            var savedIdx = rootPath.indexOf("|saved:");
            if (savedIdx !== -1) rootPath = rootPath.substring(0, savedIdx);
            lastTreePath = rootPath;
        };

        // 저장: 로컬 트리의 Ae/Pr 폴더에 다른 이름으로 저장
        saveBtn.onClick = function () {
            if (!app.project) { alert("\uD504\uB85C\uC81D\uD2B8\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4."); return; }
            var defName = "project";
            try {
                if (app.project.file) defName = decodeName(app.project.file.name).replace(/\.[^.]+$/, "");
            } catch(e) {}
            var saveName = prompt("\uC800\uC7A5\uD560 \uD30C\uC77C \uC774\uB984:", defName);
            if (!saveName) return;
            var r = saveProjectToTree(lastTreePath, saveName);
            if (r.indexOf("error: no tree path") === 0 || r.indexOf("error: tree not found") === 0) {
                // 트리에 저장돼 있지 않고 마지막 트리도 없음 -> 폴더 직접 선택
                var picked2 = browseFolder("\uC800\uC7A5\uD560 \uD3F4\uB354\uD2B8\uB9AC \uB8E8\uD2B8 \uC120\uD0DD (Ae/Pr \uD3F4\uB354 \uD3EC\uD568)");
                if (!picked2) return;
                r = saveProjectToTree(picked2, saveName);
            }
            if (r.indexOf("error") === 0) alert("\uC800\uC7A5 \uC2E4\uD328: " + r);
        };

        // 파일 임포트 + 자동분류 (AE 전용)
        importBtn.onClick = function () {
            if (IS_PREMIERE) { alert("\uD30C\uC77C \uC784\uD3EC\uD2B8\uB294 After Effects\uC5D0\uC11C\uB9CC \uC9C0\uC6D0\uB429\uB2C8\uB2E4."); return; }
            // 설정에 기본 임포트 경로가 있으면 사용, 없으면 탐색기로 선택
            var imPath = getSetting("importPath", "");
            if (!imPath) {
                imPath = browseFolder("\uC784\uD3EC\uD2B8\uD560 \uD3F4\uB354 \uC120\uD0DD");
                if (!imPath) return;
            }
            var r = importFolderAndClassify(imPath);
            if (r.indexOf("error") === 0) alert("\uC784\uD3EC\uD2B8 \uC2E4\uD328: " + r);
        };

        // 렌더 (AE 전용). Shift+클릭 = 자동 출력(즉시 렌더 후 00_Master)
        renderBtn.onClick = function () {
            if (IS_PREMIERE) { alert("\uB80C\uB354\uB294 After Effects\uC5D0\uC11C\uB9CC \uC9C0\uC6D0\uB429\uB2C8\uB2E4."); return; }
            var auto = ScriptUI.environment.keyboardState.shiftKey;
            var r = renderComps(lastTreePath, auto);
            if (r.indexOf("error") === 0) {
                var msg;
                if (r.indexOf("no comps") !== -1) msg = "\uB80C\uB354\uD560 \uCEF4\uD504\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.";
                else if (r.indexOf("no master") !== -1) msg = "00_Master \uD3F4\uB354\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.\n\uB85C\uCEEC \uD3F4\uB354\uD2B8\uB9AC\uB97C \uBA3C\uC800 \uB9CC\uB4E4\uC5B4\uC8FC\uC138\uC694.";
                else msg = "\uB80C\uB354 \uC2E4\uD328: " + r;
                alert(msg);
            } else if (r.indexOf("rendered:") === 0) {
                alert("\uB80C\uB354 \uC644\uB8CC! " + r.substring(9) + "\uAC1C \uD30C\uC77C\uC744 00_Master\uC5D0 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4.");
            }
        };

        // ────────────────────────────────────────────────────────────────────
        loadBtn.onClick = function () {
            var items = getSelectedItems();
            if (!items.length) return;
            var parsed = parseCompName(getItemName(items[0]));

            rClient.ctrl.text   = parsed.client;
            rCampaign.ctrl.text = parsed.campaign;
            rPage.ctrl.text     = parsed.page;
            rTask.ctrl.text     = parsed.task;

            function selectInDropdown(dd, value) {
                if (!value) { dd.selection = 0; return; }
                for (var i = 0; i < dd.items.length; i++) {
                    var itemText = String(dd.items[i].text);
                    if (itemText === value || jobKindCode(itemText) === value ||
                        resCode(itemText) === value) {
                        dd.selection = i; return;
                    }
                }
                dd.selection = 0;
            }
            selectInDropdown(rRes.ctrl, parsed.resolution);
            selectInDropdown(rJobKind.ctrl, parsed.jobKind);
            selectInDropdown(rType.ctrl, parsed.workType);
        };

        clearBtn.onClick = function () {
            rClient.ctrl.text   = "";
            rCampaign.ctrl.text = "";
            rPage.ctrl.text     = "";
            rTask.ctrl.text     = "";
            rRes.ctrl.selection   = 0;  // None
            rJobKind.ctrl.selection = 0;  // None
            rType.ctrl.selection  = 0;  // None
        };

        // ────────────────────────────────────────────────────────────────────
        // ────────────────────────────────────────────────────────────────────
        win.layout.layout(true);
        try { win.layout.resize(); } catch (e) {}
        win.onResizing = win.onResize = function () {
            try { win.layout.resize(); } catch (e) {}
        };

        if (!isPanel) {
            try {
                var ps = win.preferredSize;
                if (ps && ps.width) win.minimumSize = [ps.width, ps.height];
            } catch (e) {}
        }

        return win;
    }

    // ========================================================================
    // ========================================================================
    var ui = buildUI(thisObj);
    if (ui instanceof Window) {
        ui.center();
        ui.show();
    } else {
        try { ui.layout.layout(true); } catch (e) {}
    }

})(this);
