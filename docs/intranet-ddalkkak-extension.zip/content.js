// content.js — intranet.adef.co.kr 전용 파서 v4

(function () {
  "use strict";

  function getParam(name) {
    return new URLSearchParams(window.location.search).get(name);
  }

  // ── 레이블로 값 찾기 ─────────────────────────────────────
  // "제목", "기획안 링크" 등 .view_form__title 텍스트로 옆 값 탐색
  function getByLabel(labelText) {
    const titles = document.querySelectorAll(".view_form__title");
    for (const el of titles) {
      if (el.innerText.trim() === labelText) {
        const content = el.nextElementSibling;
        if (content) return content.innerText.trim();
      }
    }
    return null;
  }

  // 레이블 옆 <a> 태그 링크 수집
  function getLinksByLabel(labelText) {
    const titles = document.querySelectorAll(".view_form__title");
    for (const el of titles) {
      if (el.innerText.trim() === labelText) {
        const content = el.nextElementSibling;
        if (content) {
          return Array.from(content.querySelectorAll("a[href]"))
            .map(a => ({ type: "link", label: a.innerText.trim() || a.href, value: a.href }));
        }
      }
    }
    return [];
  }

  // ── 기획안 링크 후보 수집 ────────────────────────────────
  function collectPlanLinks() {
    const results = [];
    const seen = new Set();

    function add(item) {
      if (!item.value || seen.has(item.value)) return;
      seen.add(item.value);
      results.push(item);
    }

    // ① "기획안 링크" 레이블 옆 링크 우선
    getLinksByLabel("기획안 링크").forEach(add);
    getLinksByLabel("기획안").forEach(add);

    // ② .view_form__content--anchor (구글드라이브 등)
    document.querySelectorAll(".view_form__content--anchor").forEach(a => {
      if (a.href && a.href !== "#") add({ type: "link", label: a.innerText.trim() || a.href, value: a.href });
    });

    // ③ .view_form__content 내 모든 <a>
    document.querySelectorAll(".view_form__content a[href]").forEach(a => {
      if (a.href && a.href !== "#") add({ type: "link", label: a.innerText.trim() || a.href, value: a.href });
    });

    // ④ NAS 경로 텍스트
    document.querySelectorAll(".view_form__content").forEach(container => {
      const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        const t = node.textContent.trim();
        if (t.length < 5) continue;
        if (/^\/(cr|nas|NAS|CR|server)\//i.test(t) || /\/(cr|nas)\//i.test(t)) {
          add({ type: "nas", label: "📁 " + t.slice(0, 100), value: t });
        }
      }
    });

    // ⑤ 첨부파일
    document.querySelectorAll("a[href]").forEach(a => {
      if (/\.(pptx?|xlsx?|docx?|pdf|zip)(\?|$)/i.test(a.href)) {
        add({ type: "file", label: "📎 " + (a.innerText.trim() || a.href.split("/").pop()), value: a.href });
      }
    });

    return results;
  }

  // ── 메인 파싱 ────────────────────────────────────────────
  function parsePageData() {

    // ① 제목 — "제목" 레이블 옆 .view_form__content--txt
    const titleEl = (function() {
      const labels = document.querySelectorAll(".view_form__title");
      for (const el of labels) {
        if (el.innerText.trim() === "제목") {
          return el.nextElementSibling?.querySelector(".view_form__content--txt");
        }
      }
      return null;
    })();
    const title = titleEl ? titleEl.innerText.trim() : null;

    // ② 희망완료일
    const dueDateEl = document.querySelector("input[name='end_date']");
    const dueDate = dueDateEl ? dueDateEl.value.trim() : null;

    // ③ 처리자 — select#crlist 선택된 option
    const assigneeEl = document.querySelector("select#crlist");
    let assignee = null;
    if (assigneeEl) {
      const sel = assigneeEl.querySelector("option[selected]")
                || assigneeEl.options[assigneeEl.selectedIndex];
      assignee = sel ? sel.innerText.trim() : null;
    }

    // ④ 기획안 링크 후보
    const linkCandidates = collectPlanLinks();

    return {
      url: window.location.href,
      idx: getParam("idx"),
      title,
      dueDate,
      assignee,
      linkCandidates,
    };
  }

  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.action === "parsePage") {
      try {
        sendResponse({ success: true, data: parsePageData() });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    }
    return true;
  });
})();
