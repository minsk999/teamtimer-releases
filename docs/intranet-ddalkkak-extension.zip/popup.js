// popup.js — 인트라넷 딸깍

const $ = id => document.getElementById(id);

// 팀원 명단은 시트('🤖자동화' A열)에서 받아온다 — 코드에 고정하지 않음.
// 받기 전에는 저장해둔 목록, 그것도 없으면 아래 기본값을 쓴다.
const MEMBERS_FALLBACK = ["구민석","한영채","주지현","박나진","김본희","구정현"];
let MEMBERS = MEMBERS_FALLBACK.slice();

const DEFAULT_URL = "https://script.google.com/macros/s/AKfycbzpYvgADNXn3POEe-XDsOVR9Q1AvH_xJ_d38vymNNkjdKCtjtEIiSJJVrpX61FA_6wGbg/exec";
// 새 버전을 받는 곳. 알림 바의 「받으러 가기」가 여기로 간다.
const RELEASES_URL = "https://minsk999.github.io/teamtimer-releases/";
const MAX_HISTORY = 20;

// 설치된 확장의 버전. manifest.json 하나만 고치면 화면·전송·알림이 전부 따라온다.
const APP_VER = chrome.runtime.getManifest().version;

// Apps Script 는 콜드 스타트가 있어 첫 전송이 수 초 걸린다.
// 타임아웃이 없으면 네트워크가 끊겼을 때 fetch 가 무기한 pending 으로 남는다.
const SEND_TIMEOUT_MS = 20000;
// 느림 힌트. 2026-09-18 실측: 쓰기 없는 경로만 2.4~3.3초, 실제 삽입은 +1~3초 → 정상이 4~6초다.
// 3초였을 땐 매번 떴고 문구가 「첫 전송」·「깨우는 중」이라 거짓이었다(사용자 지적).
// 8초는 정상 범위 밖 — 뜨면 진짜 느린 것이고, 20초 타임아웃까지 기다린다는 뜻을 담는다.
const SLOW_HINT_MS    = 8000;

let myName = "", sheetUrl = "", parsedData = null;
let sending = false;      // 전송 중복 진입 차단
let sentUrl = "";         // 이 팝업에서 전송 성공한 게시글 — 탭을 오가도 다시 안 보내게

// ── 즉시 웜업 ────────────────────────────────────────────────
// 콜드 스타트를 미리 깨운다. 실패해도 아무 일 없다.
chrome.storage.local.get(["sheetUrl"], d => {
  fetch((d.sheetUrl || DEFAULT_URL) + "?warmup=1").catch(() => {});
});

// ══════════════════════════════════════════════════════════════
//  표시 헬퍼 — JS 는 색을 만지지 않는다. 클래스만 토글한다.
// ══════════════════════════════════════════════════════════════

// 결과 표시. 대기·진행은 버튼이 말하므로 여기엔 '결과'만 넣는다.
// msg 가 비면 아예 숨긴다 — 빈 상자가 40px 를 먹지 않도록.
function showStatus(msg, type) {
  const el = $("status-msg");
  if (!el) return;
  if (!msg) {
    // v1.5 처럼 상자는 항상 있다 — 비우라고 하면 지금 상태를 쓴다.
    // 상자가 사라졌다 나타나면 아래 버튼이 48px 뛴다.
    if (sending)                         { el.textContent = "구글 시트로 전송 중...";       el.className = "status info"; }
    else if (parsedData && parsedData.title) { el.textContent = myName + " 시트로 전송됩니다"; el.className = "status success"; }
    else                                 { el.textContent = "불러오기 전";                 el.className = "status"; }
    el.hidden = false;
    return;
  }
  el.textContent = msg;
  el.className = "status" + (type ? " " + type : "");
  el.hidden = false;
}

// 설정 탭 결과. 예전엔 alert 과 버튼 라벨 치환으로 흩어져 있었다.
// v1.8.2: 줄은 항상 자리를 차지하고(점프 없음) 글자만 켜졌다 꺼진다.
//   성공·안내는 2.2초 뒤 스스로 꺼진다. 오류·경고는 읽어야 하니 다음 동작까지 남는다.
let settingsStatusTimer = null, settingsStatusClear = null;
function showSettingsStatus(msg, type) {
  const el = $("s-status");
  if (!el) return;
  clearTimeout(settingsStatusTimer); clearTimeout(settingsStatusClear);
  const off = () => {
    el.classList.remove("on");
    settingsStatusClear = setTimeout(() => { if (!el.classList.contains("on")) el.textContent = ""; }, 250);  // 페이드아웃 뒤 비움
  };
  if (!msg) { off(); return; }
  el.textContent = msg;
  el.className = "status slim on" + (type ? " " + type : "");
  if (type !== "error" && type !== "warn") settingsStatusTimer = setTimeout(off, 2200);
}

// 처리자 — v1.5 그대로: 값 상자에 이름, 옆에 개인(파랑)/공동(보라) 배지.
// 시트로 보내지 않는 참고 정보다.
function setAssignee(name) {
  const el = $("f-assignee"), tag = $("f-assignee-tag");
  if (!el) return;
  if (name) { el.textContent = name; el.classList.remove("empty"); }
  else      { el.textContent = "—";  el.classList.add("empty"); }
  if (!tag) return;
  if (name && MEMBERS.includes(name)) {
    tag.textContent = "개인"; tag.className = "assignee-tag badge me";   tag.style.display = "";
  } else if (name) {
    tag.textContent = "공동"; tag.className = "assignee-tag badge team"; tag.style.display = "";
  } else {
    tag.style.display = "none";
  }
}

// 전송 버튼의 세 상태를 한 곳에서 정한다.
function setSendState(state) {
  const b = $("btn-send");
  if (!b) return;
  const target = myName ? myName + " 시트로 전송" : "구글 시트로 전송";
  b.classList.remove("loading");
  if (state === "sending") {
    b.textContent = "전송 중…";
    b.classList.add("loading");
    b.disabled = true;
  } else if (state === "done") {
    b.textContent = target;
    b.disabled = true;      // 같은 게시글 재전송 방지
  } else if (state === "blocked") {
    b.textContent = target;
    b.disabled = true;      // 제목이 없어 보낼 수 없음
  } else {
    b.textContent = target;
    b.disabled = false;
  }
}

// 제목이 있어야만 보낼 수 있다. 파싱이 실패해도 손으로 채우면 보낼 수 있어야 한다.
function refreshSendGate() {
  if (sending) return;
  const hasTitle = $("f-title").value.trim().length > 0;
  if (!hasTitle) { setSendState("blocked"); return; }
  if (sentUrl && parsedData && parsedData.url === sentUrl) { setSendState("done"); return; }
  setSendState("ready");
}

// 다양한 날짜 표기를 <input type="date">용 YYYY-MM-DD로 변환
function toDateInputValue(s) {
  if (!s) return "";
  const m = String(s).match(/(\d{4})\D*(\d{1,2})\D*(\d{1,2})/);
  if (!m) return "";
  return m[1] + "-" + m[2].padStart(2, "0") + "-" + m[3].padStart(2, "0");
}

// 응답이 JSON 이 아닐 때(구글 로그인 리다이렉트, 할당량 초과 등)
// SyntaxError 원문이 사용자에게 그대로 가던 것을 사람이 읽을 문장으로 바꾼다.
async function asJson(res) {
  const text = await res.text();
  if (!res.ok) throw new Error("서버 응답 오류 (" + res.status + ")");
  try { return JSON.parse(text); }
  catch {
    console.error("JSON 아님:", text.slice(0, 300));
    throw new Error("시트 주소가 만료됐거나 접근 권한이 바뀐 것 같아요. 설정 탭에서 연결 테스트를 눌러보세요.");
  }
}

// ── 팀원 명단 ────────────────────────────────────────────────
function renderMemberOptions(keep) {
  const sel = $("s-myname");
  if (!sel) return;
  // 화면의 현재 선택값이 우선. keep(저장값)은 폴백이다.
  // 반대로 두면 사용자가 이름을 고르는 사이 명단 응답이 도착해 되돌려버린다.
  const cur = sel.value || keep || "";
  sel.innerHTML = '<option value="">— 선택 —</option>';
  MEMBERS.forEach(n => {
    const o = document.createElement("option");
    o.value = n; o.textContent = n;
    sel.appendChild(o);
  });
  if (cur && MEMBERS.indexOf(cur) !== -1) sel.value = cur;
}

// 저장된 이름이 명단에서 사라졌으면 알린다.
// 예전엔 select 만 비고 모듈 변수는 옛 이름을 들고 있어 그대로 전송됐다.
function checkMyNameStillValid() {
  if (!myName) return;
  if (MEMBERS.indexOf(myName) !== -1) return;
  showSettingsStatus("설정된 이름(" + myName + ")이 시트 명단에 없어요. 다시 선택해 주세요.", "error");
}

// 시트에서 최신 명단 가져오기. 실패해도 캐시/기본값으로 계속 동작.
// action=members 는 업무현황 시트를 읽지 않아 매우 가볍다.
function refreshMembers(url, keep) {
  fetch((url || DEFAULT_URL) + "?action=members")
    .then(r => r.json())
    .then(j => {
      if (!j || !j.ok) return;
      // v1.8.4: 팝업을 열 때 바로 안다(서버 v61+ 가 members 응답에 실어 보낸다). 예전엔 전송 응답에만 있었다.
      if (j.latestVer) noteNewVersion(j.latestVer, j.updateMsg);
      if (!Array.isArray(j.members) || !j.members.length) return;
      if (j.members.join("|") === MEMBERS.join("|")) return;   // 변화 없음
      MEMBERS = j.members.slice();
      chrome.storage.local.set({ memberNames: MEMBERS });
      renderMemberOptions(keep);
      checkMyNameStillValid();
    })
    .catch(() => {});
}

// ── 새 버전 알림 ─────────────────────────────────────────────
// 알림은 전송 응답으로만 오지만, 실제로 업데이트할 때까지 팝업을 열 때마다 보여야 한다.
// 그래서 storage 에 남기고, 버전이 올라가면 스스로 지운다.
function showUpdateBar(ver, msg) {
  const bar = $("update-bar");
  if (!bar) return;
  $("update-ver").textContent = "v" + ver;
  const m = $("update-msg"); if (m) m.textContent = msg || "";
  const a = $("update-link");
  if (a) { a.href = RELEASES_URL; a.title = (msg || "").replace(/^[—\-\s]+/, "") || "새 버전 받는 곳"; }
  bar.title = a ? a.title : "";
  bar.classList.add("show");
}

// a < b ? 서버의 verLt 와 같은 규칙 — "1.10" 과 "1.9" 를 문자열로 비교하면 틀리고,
// "1.8" 과 "1.8.3" 을 !== 로 비교하면 이미 올린 뒤에도 옛 알림이 남는다. 자리별 숫자로 본다.
function verLt(a, b) {
  const x = String(a || "0").split("."), y = String(b || "0").split(".");
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) {
    const p = parseInt(x[i], 10) || 0, q = parseInt(y[i], 10) || 0;
    if (p !== q) return p < q;
  }
  return false;
}

function noteNewVersion(ver, msg) {
  if (!ver || !verLt(APP_VER, ver)) return;   // 지금 것보다 새 것일 때만
  chrome.storage.local.set({ updateNotice: { ver: ver, msg: msg || "" } });
  showUpdateBar(ver, msg);
}

function restoreUpdateNotice() {
  chrome.storage.local.get(["updateNotice"], d => {
    const n = d.updateNotice;
    if (!n || !n.ver) return;
    if (!verLt(APP_VER, n.ver)) { chrome.storage.local.remove("updateNotice"); return; }   // 이미 그 이상이면 지운다
    showUpdateBar(n.ver, n.msg);
  });
}

// ── 끝나지 않은 전송 경고 ────────────────────────────────────
// 팝업이 닫히면 진행 중인 fetch 는 끊기지만 요청은 이미 나갔다 —
// 서버는 끝까지 실행해 시트에 행을 쓰는데 기록에는 안 남는다.
// 그러면 실패로 알고 다시 눌러 중복이 생긴다.
function markPending(url) {
  chrome.storage.local.set({ pendingSend: { url: url || "", at: Date.now() } });
}
function clearPending() {
  chrome.storage.local.remove("pendingSend");
}
function checkPending() {
  chrome.storage.local.get(["pendingSend"], d => {
    if (!d.pendingSend) return;
    clearPending();
    showStatus("지난번 전송이 끝났는지 확실하지 않아요. 시트를 확인해 주세요.", "warn");
  });
}

// ── 탭 전환 ─────────────────────────────────────────────────
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => {
      t.classList.remove("active");
      t.setAttribute("aria-selected", "false");
    });
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    tab.classList.add("active");
    tab.setAttribute("aria-selected", "true");
    $("tab-" + tab.dataset.tab).classList.add("active");
    if (tab.dataset.tab === "fetch")   refreshFetchTab();
    if (tab.dataset.tab === "history") loadHistory();
  });
});

// ── 설정 로드 ────────────────────────────────────────────────
function loadSettings(cb) {
  chrome.storage.local.get(["myName", "sheetUrl", "dupCheck", "memoPSuffix", "memberNames"], d => {
    myName   = d.myName   || "";
    sheetUrl = d.sheetUrl || DEFAULT_URL;
    if (Array.isArray(d.memberNames) && d.memberNames.length) MEMBERS = d.memberNames.slice();
    renderMemberOptions(d.myName || "");
    if (d.myName) $("s-myname").value = d.myName;
    refreshMembers(sheetUrl, d.myName || "");
    $("s-sheet-url").value  = sheetUrl;
    $("s-dupcheck").checked = d.dupCheck !== false;
    const mpt = $("memo-p-toggle");
    if (mpt) { mpt.checked = !!d.memoPSuffix; syncMemoPlaceholder(); }
    touchDevice();
    if (cb) cb();
  });
}

function syncMemoPlaceholder() {
  const on = !!$("memo-p-toggle")?.checked;
  $("f-memo").placeholder = on ? "메모 기록 (끝에 p가 붙어요)" : "메모 기록 (선택)";
}

document.addEventListener("DOMContentLoaded", () => {
  $("app-ver").textContent = "· v" + APP_VER;
  restoreUpdateNotice();
  checkPending();

  $("update-x")?.addEventListener("click", () => {
    $("update-bar").classList.remove("show");   // 이번 팝업에서만 숨김 — 다음에 다시 뜬다
  });

  $("s-dupcheck")?.addEventListener("change", e => {
    chrome.storage.local.set({ dupCheck: e.target.checked });
  });
  $("memo-p-toggle")?.addEventListener("change", e => {
    chrome.storage.local.set({ memoPSuffix: e.target.checked });
    syncMemoPlaceholder();
  });

  // 제목을 손으로 채우면 전송이 열린다 — 파싱이 실패해도 쓸 수 있어야 한다
  $("f-title")?.addEventListener("input", refreshSendGate);

  // 직접 입력이 있으면 위 선택은 무시된다. 그걸 화면에 드러낸다.
  const custom = $("f-link-custom"), links = $("f-links"), note = $("f-link-ignore");
  custom?.addEventListener("input", () => {
    const on = custom.value.trim().length > 0;
    links.classList.toggle("ignored", on);
    note.hidden = !on;
  });

  // 팝업 어디서든 Enter = 전송. 단 아래는 그 요소 본래 동작을 살린다:
  //  - 한글 조합을 끝내는 Enter(조합 확정 직후 오전송 방지)
  //  - 키 자동반복(누르고 있으면 여러 번 발화)
  //  - select/버튼/링크/체크박스 등
  //  - 희망완료일 칸(readonly 라 포커스는 받는데 캘린더 트리거가 click 뿐이라
  //    Enter 가 그대로 전송으로 새던 것)
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    if (e.isComposing || e.keyCode === 229) return;
    if (e.repeat) return;
    const t = e.target;
    const tag = (t && t.tagName) ? t.tagName.toUpperCase() : "";
    const type = (t && t.type) ? String(t.type).toLowerCase() : "";
    if (t && t.id === "f-duedate") { e.preventDefault(); openDatePicker(); return; }
    if (tag === "SELECT" || tag === "BUTTON" || tag === "A" || tag === "TEXTAREA") return;
    if (type === "checkbox" || type === "radio") return;
    const fetchPanel = $("tab-fetch");
    const mainState  = $("state-main");
    if (!fetchPanel || !fetchPanel.classList.contains("active")) return;
    if (!mainState || mainState.style.display === "none") return;
    e.preventDefault();
    $("btn-send")?.click();   // 비활성이면 자연히 무시된다
  });

  // 희망완료일: 칸을 클릭(또는 Enter/Space)하면 캘린더, 고르면 텍스트칸을 ISO로 채움
  const dueText = $("f-duedate"), duePicker = $("f-duedate-picker");
  dueText?.addEventListener("click", openDatePicker);
  dueText?.addEventListener("keydown", e => {
    if (e.key === " ") { e.preventDefault(); openDatePicker(); }
  });
  duePicker?.addEventListener("change", e => {
    if (e.target.value) {
      dueText.value = e.target.value;
      dueText.classList.remove("empty");
    }
  });
});

function openDatePicker() {
  const p = $("f-duedate-picker");
  if (!p) return;
  try { p.showPicker(); }
  catch (e) { p.focus(); p.click(); }   // 폴백
}

// ── 설정 저장 ────────────────────────────────────────────────
$("btn-save").addEventListener("click", () => {
  const name = $("s-myname").value;
  const url  = $("s-sheet-url").value.trim();
  if (!name) { showSettingsStatus("이름을 선택해 주세요.", "warn"); $("s-myname").focus(); return; }
  if (!url)  { showSettingsStatus("시트 주소를 입력해 주세요.", "warn"); $("s-sheet-url").focus(); return; }
  chrome.storage.local.set({ myName: name, sheetUrl: url, dupCheck: $("s-dupcheck").checked }, () => {
    myName = name; sheetUrl = url;
    showSettingsStatus("저장했어요.", "success");
    refreshFetchTab();
  });
});

// ── 연결 테스트 ──────────────────────────────────────────────
let testTimer = null;
$("btn-test").addEventListener("click", async () => {
  const url = $("s-sheet-url").value.trim();
  const b = $("btn-test");
  if (!url) { showSettingsStatus("시트 주소를 입력해 주세요.", "warn"); return; }
  clearTimeout(testTimer);
  b.disabled = true;
  b.classList.add("loading");
  showSettingsStatus("");
  const started = Date.now();
  try {
    const data = await fetch(url + "?test=1").then(asJson);
    await minDelay(started);
    showSettingsStatus(data.ok ? "연결됐어요." : "응답이 이상해요. 주소를 확인해 주세요.", data.ok ? "success" : "error");
  } catch (e) {
    await minDelay(started);
    showSettingsStatus(e.message || "연결에 실패했어요.", "error");
  } finally {
    b.disabled = false;
    b.classList.remove("loading");
  }
});

// 응답이 너무 빨리 오면 '확인 중'이 한 프레임 깜빡이고 사라진다
function minDelay(started, ms) {
  const left = (ms || 400) - (Date.now() - started);
  return left > 0 ? new Promise(r => setTimeout(r, left)) : Promise.resolve();
}

// ── 기록 (chrome.storage.sync) ──────────────────────────────
// sync 는 항목당 8KB(UTF-8 바이트) 제한. String.length 는 UTF-16 코드유닛이라
// 한글에서 3배 차이가 난다 — TextEncoder 로 실제 바이트를 잰다.
function byteLen(s) {
  try { return new TextEncoder().encode(s).length; }
  catch { return s.length * 3; }
}

// sync 와 local 을 합친다 — url 로 중복 제거, 날짜(yy/mm/dd) 내림차순, 같은 날이면 앞에 온 것 우선.
// 예전엔 sync 쓰기가 실패하면 local 로 떨어졌다가, 다음에 sync 가 성공하면 그 local 을 지웠다.
// 한쪽 PC 에 쌓인 기록이 합쳐지지 않고 사라지는 경로였다.
function mergeHistory() {
  const seen = new Set(), out = [];
  for (const list of arguments) {
    (list || []).forEach(h => {
      if (!h || !h.url || seen.has(h.url)) return;
      seen.add(h.url); out.push(h);
    });
  }
  out.sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));   // 안정 정렬
  return out;
}

function saveHistory(item) {
  chrome.storage.sync.get(["history"], d => {
    chrome.storage.local.get(["history"], l => {
      const fresh = { title: (item.title || "").slice(0, 60), url: item.url || "", date: item.date };
      let hist = mergeHistory([fresh], d.history, l.history);
      if (hist.length > MAX_HISTORY) hist = hist.slice(0, MAX_HISTORY);
      while (hist.length > 1 && byteLen(JSON.stringify({ history: hist })) > 7500) hist.pop();
      // local 은 항상 같이 쓴다 — sync 가 안 되는 PC 에서도 기록은 남아야 하고,
      // 나중에 sync 가 붙으면 위 merge 가 알아서 합친다. 지우지 않는다.
      chrome.storage.local.set({ history: hist });
      chrome.storage.sync.set({ history: hist });
    });
  });
}

function loadHistory() {
  chrome.storage.sync.get(["history"], d => {
    chrome.storage.local.get(["history"], l => {
      renderHistory(mergeHistory(d.history, l.history).slice(0, MAX_HISTORY));
    });
  });
}

// ── 동기화 도장 ─────────────────────────────────────────────
// chrome.storage.sync 는 크롬이 같은 구글 계정으로 로그인 + 동기화 켜짐일 때만 PC 를 넘어간다.
// 아니면 크롬이 조용히 local 처럼 동작한다 — 오류도 없고 화면도 같아서 구별이 안 됐다.
// 그래서 PC 마다 도장을 sync 에 찍는다. 다른 PC 도장이 보이면 동기화가 실제로 건너온 것이다.
function touchDevice() {
  chrome.storage.local.get(["deviceId"], l => {
    let id = l.deviceId;
    if (!id) {
      id = (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
      chrome.storage.local.set({ deviceId: id });
    }
    chrome.storage.sync.get(["devices"], d => {
      const dev = d.devices || {}, now = Date.now();
      dev[id] = now;
      Object.keys(dev).forEach(k => { if (now - dev[k] > 60 * 864e5) delete dev[k]; });   // 60일 안 본 PC 는 정리
      chrome.storage.sync.set({ devices: dev }, () => renderSyncStatus(id, dev, !!chrome.runtime.lastError));
    });
  });
}

function renderSyncStatus(myId, dev, failed) {
  const el = $("s-sync");
  if (!el) return;
  const others = Object.keys(dev).filter(k => k !== myId);
  if (failed) {
    el.textContent = "기록 동기화 · 저장소에 못 썼어요. 이 PC 에만 남습니다.";
  } else if (!others.length) {
    el.textContent = "기록 동기화 · 다른 PC 는 아직 안 보여요 — 크롬이 같은 구글 계정으로 동기화 중이어야 해요.";
  } else {
    const last = new Date(Math.max.apply(null, others.map(k => dev[k])));
    const mm = String(last.getMonth() + 1).padStart(2, "0"), dd = String(last.getDate()).padStart(2, "0");
    const hh = String(last.getHours()).padStart(2, "0"), mi = String(last.getMinutes()).padStart(2, "0");
    el.textContent = "기록 동기화 · 다른 PC " + others.length + "대와 함께 씁니다 (그쪽 마지막 " + mm + "/" + dd + " " + hh + ":" + mi + ")";
  }
  // 확장 ID — 두 PC 가 같아야 동기화가 붙는다. 마우스 올리면 보인다.
  el.title = "확장 ID " + (chrome.runtime.id || "") + " — 두 PC 에서 같아야 합니다";
}

// 게시글 제목은 남이 쓴 문자열이다. innerHTML 로 조립하면
// '<A안>' 같은 ASCII 시작 꺾쇠가 태그로 파싱돼 줄이 사라진다.
function renderHistory(hist) {
  const listEl = $("history-list");
  $("history-empty").hidden  = hist.length > 0;
  $("history-footer").style.display = hist.length ? "flex" : "none";
  listEl.innerHTML = "";
  hist.forEach(h => {
    const a = document.createElement("a");
    a.className = "history-item";
    a.target = "_blank";
    if (/^https?:\/\//i.test(h.url || "")) a.href = h.url;
    const t = document.createElement("div");
    t.className = "history-title";
    t.textContent = h.title || h.url || "(제목 없음)";
    const dt = document.createElement("div");
    dt.className = "history-date";
    dt.textContent = h.date || "";
    a.append(t, dt);
    listEl.appendChild(a);
  });
}

// 기록 전체 삭제 — sync 라 같은 계정의 다른 PC 에서도 지워지고 되돌릴 수 없다.
// 예전엔 무장 후 최소 대기가 없어 더블클릭이면 확인 없이 실행됐다.
let confirmTimer = null;
$("btn-clear-history").addEventListener("click", () => {
  const b = $("btn-clear-history");
  if (b.dataset.confirm !== "1") {
    b.dataset.confirm = "1";
    b.dataset.armedAt = String(Date.now());
    b.textContent = "정말 삭제할까요?";
    b.classList.remove("quiet");
    b.classList.add("danger", "arming");
    clearTimeout(confirmTimer);
    confirmTimer = setTimeout(() => disarmClear(), 3000);
    return;
  }
  if (Date.now() - Number(b.dataset.armedAt || 0) < 400) return;   // 더블클릭 오폭 차단
  clearTimeout(confirmTimer);
  chrome.storage.sync.remove("history", () => {
    chrome.storage.local.remove("history", () => {
      disarmClear();
      loadHistory();
    });
  });
});

function disarmClear() {
  const b = $("btn-clear-history");
  if (!b) return;
  b.dataset.confirm = "0";
  b.textContent = "기록 전체 삭제";
  b.classList.remove("danger", "arming");
  b.classList.add("quiet");
}

// ── 가져오기 탭 갱신 ────────────────────────────────────────
function refreshFetchTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const isIntranet = (tabs[0]?.url || "").includes("intranet.adef.co.kr/video/view");
    $("state-not-intranet").style.display = "none";
    $("state-no-settings").style.display  = "none";
    $("state-main").style.display         = "none";

    if (!isIntranet) {
      $("state-not-intranet").style.display = "block";
    } else if (!myName || !sheetUrl) {
      $("state-no-settings").style.display = "block";
    } else {
      $("state-main").style.display = "block";
      if (!parsedData) parseTab(tabs[0].id);
      else refreshSendGate();
    }
    document.body.classList.add("ready");
  });
}

// ── 초기 화면 ────────────────────────────────────────────────
loadSettings(() => {
  if (!myName) {
    document.querySelectorAll(".tab").forEach(t => {
      t.classList.remove("active");
      t.setAttribute("aria-selected", "false");
    });
    document.querySelectorAll(".tab-panel").forEach(el => el.classList.remove("active"));
    const st = document.querySelector('[data-tab="settings"]');
    st.classList.add("active");
    st.setAttribute("aria-selected", "true");
    $("tab-settings").classList.add("active");
    document.body.classList.add("ready");
  } else {
    refreshFetchTab();
  }
});

// ── 불러오기 ────────────────────────────────────────────────
// manifest 가 이미 content.js 를 주입하므로 먼저 말을 걸어 본다.
// 확장을 갓 설치했거나 탭을 아직 새로고침하지 않은 경우에만 주입한다.
// 예전엔 매번 executeScript 로 다시 주입하고 200ms 를 기다렸는데,
// 그 200ms 는 기다릴 대상이 없었고 리스너만 팝업 열 때마다 쌓였다.
function parseTab(tabId) {
  setSendState("blocked");
  showStatus("불러오는 중...", "info");
  chrome.tabs.sendMessage(tabId, { action: "parsePage" }, res => {
    if (chrome.runtime.lastError) return injectThenParse(tabId);
    render(res);
  });
}

function injectThenParse(tabId) {
  chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
    if (chrome.runtime.lastError) return renderFailure();
    chrome.tabs.sendMessage(tabId, { action: "parsePage" }, res => {
      if (chrome.runtime.lastError) return renderFailure();
      render(res);
    });
  });
}

// 파싱이 통째로 실패해도 폼은 살려 둔다 — 손으로 채워 보낼 수 있어야 한다.
function renderFailure() {
  parsedData = null;
  setAssignee("");
  $("f-title").classList.add("empty");
  showStatus("게시글을 읽지 못했어요. 직접 채워서 보내셔도 됩니다.", "warn");
  refreshSendGate();
}

function render(res) {
  if (!res?.success) return renderFailure();
  const prev = parsedData;
  parsedData = res.data;

  // 같은 게시글을 다시 불러온 것이면 손으로 쓰던 메모를 지키지 않는다
  const sameDoc = prev && prev.url === parsedData.url;
  const keptMemo = sameDoc ? $("f-memo").value : "";

  $("f-title").value = parsedData.title || "";
  $("f-title").classList.toggle("empty", !parsedData.title);

  const dueISO = toDateInputValue(parsedData.dueDate);
  $("f-duedate").value = dueISO;
  $("f-duedate").classList.toggle("empty", !dueISO);
  $("f-duedate-picker").value = dueISO;

  setAssignee(parsedData.assignee);
  $("f-memo").value = keptMemo;
  $("f-link-custom").value = sameDoc ? $("f-link-custom").value : "";

  // 기획안 링크 후보
  const sel = $("f-links");
  sel.innerHTML = '<option value="">— 선택하세요 —</option>';
  const groups = { link: "외부 링크", nas: "NAS 경로", file: "첨부파일" };
  const grouped = {};
  (parsedData.linkCandidates || []).forEach(c => {
    const t = c.type || "link";
    (grouped[t] = grouped[t] || []).push(c);
  });
  Object.entries(groups).forEach(([type, label]) => {
    if (!grouped[type]?.length) return;
    const og = document.createElement("optgroup");
    og.label = label;
    grouped[type].forEach(c => {
      const o = document.createElement("option");
      o.value = c.value; o.textContent = c.label.slice(0, 60);
      og.appendChild(o);
    });
    sel.appendChild(og);
  });

  // '기획안 링크' 라벨에서 온 후보가 있을 때만 자동 선택한다.
  // 예전엔 본문의 아무 첫 링크(공지·푸터 pdf 등)가 조용히 선택돼 시트에 박혔다.
  const hasPrimary = (parsedData.linkCandidates || []).some(c => c.primary);
  if (hasPrimary) { sel.selectedIndex = 1; sel.classList.remove("empty"); }
  else { sel.selectedIndex = 0; sel.classList.toggle("empty", (parsedData.linkCandidates || []).length > 0); }

  if (!parsedData.title) {
    showStatus("제목을 못 읽었어요. 직접 입력해 주세요.", "warn");
  } else if (!hasPrimary && (parsedData.linkCandidates || []).length) {
    showStatus("기획안 링크를 못 찾았어요. 직접 골라주세요.", "warn");
  } else {
    showStatus("");
  }
  refreshSendGate();
}

$("btn-parse").addEventListener("click", () => {
  showStatus("");
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => parseTab(tabs[0].id));
});

// ── 전송 ────────────────────────────────────────────────────
$("btn-send").addEventListener("click", async () => {
  const b = $("btn-send");
  if (sending || b.disabled) return;
  sending = true;
  setSendState("sending");
  showStatus("");

  const planLink = $("f-link-custom").value.trim() || $("f-links").value;
  let memoVal = $("f-memo").value.trim();
  if (memoVal && $("memo-p-toggle")?.checked) memoVal += "p";

  const body = new URLSearchParams({
    targetMember: myName,
    title:        $("f-title").value.trim()    || "",
    dueDate:      toDateInputValue($("f-duedate").value) || "",
    planLink:     planLink             || "",
    memo:         memoVal              || "",
    url:          parsedData?.url      || "",
    dupCheck:     $("s-dupcheck").checked ? "1" : "0",
    ver:          APP_VER,
  }).toString();

  const ac = new AbortController();
  const to = setTimeout(() => ac.abort(), SEND_TIMEOUT_MS);
  const slow = setTimeout(() => {
    showStatus("평소보다 오래 걸리네요 — 20초까지 기다려 볼게요.", "info");   // 경고색 아님: 느린 것이지 잘못된 게 아니다
  }, SLOW_HINT_MS);

  markPending(parsedData?.url);

  try {
    const data = await fetch(sheetUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
      signal: ac.signal,
      keepalive: true,   // 팝업이 닫혀도 요청이 끝까지 나가도록
    }).then(asJson);

    clearTimeout(slow);
    if (data.latestVer) noteNewVersion(data.latestVer, data.updateMsg);

    if (data.duplicate) {
      clearPending();
      showStatus("이미 등록된 게시글이에요.", "warn");
      sending = false;
      setSendState("ready");
    } else if (data.ok) {
      clearPending();
      sentUrl = parsedData?.url || "";
      showStatus(myName + " 시트에 추가했어요");
      $("f-memo").value = "";
      saveHistory({
        title: $("f-title").value.trim() || "(제목 없음)",
        url:   parsedData?.url   || "",
        date:  new Date().toLocaleDateString("ko-KR", { year: "2-digit", month: "2-digit", day: "2-digit" })
                         .replace(/\.\s*$/, "").replace(/\.\s*/g, "/"),
      });
      sending = false;
      setSendState("done");
    } else {
      clearPending();
      showStatus(data.error || "알 수 없는 오류가 났어요.", "error");
      sending = false;
      setSendState("ready");
    }
  } catch (e) {
    clearTimeout(slow);
    sending = false;
    setSendState("ready");
    if (e.name === "AbortError") {
      showStatus("응답이 없어요. 잠시 후 다시 눌러 주세요.", "error");
      // pendingSend 는 지우지 않는다 — 서버가 이미 썼을 수 있다
    } else {
      clearPending();
      showStatus(e.message || "전송에 실패했어요.", "error");
    }
  } finally {
    clearTimeout(to);
  }
});
