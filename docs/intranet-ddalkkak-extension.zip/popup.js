// popup.js — 인트라넷 딸깍

const $ = id => document.getElementById(id);

// 팀원 명단은 시트('🤖자동화' A열)에서 받아온다 — 코드에 고정하지 않음.
// 받기 전에는 저장해둔 목록, 그것도 없으면 아래 기본값을 쓴다.
const MEMBERS_FALLBACK = ["구민석","한영채","주지현","박나진","김본희","구정현"];
let MEMBERS = MEMBERS_FALLBACK.slice();

const DEFAULT_URL = "https://script.google.com/macros/s/AKfycbzpYvgADNXn3POEe-XDsOVR9Q1AvH_xJ_d38vymNNkjdKCtjtEIiSJJVrpX61FA_6wGbg/exec";
// 새 버전을 받는 곳. 알림 바의 「받으러 가기」가 여기로 간다.
const RELEASES_URL = "https://minsk999.github.io/teamtimer-releases/#ttalkak";   // 받는 방법이 적힌 딸깍 카드로 바로
const MAX_HISTORY = 20;

// 설치된 확장의 버전. manifest.json 하나만 고치면 화면·전송·알림이 전부 따라온다.
const APP_VER = chrome.runtime.getManifest().version;

// Apps Script 는 콜드 스타트가 있어 첫 전송이 수 초 걸린다.
// 타임아웃이 없으면 네트워크가 끊겼을 때 fetch 가 무기한 pending 으로 남는다.
// 서버 최악(콜드 스타트 5~8초 + 락 대기 8초 + 쓰기·빈 줄 삽입 4~6초)이 20초를 넘을 수 있어 28초(5차 점검).
const SEND_TIMEOUT_MS = 28000;
// 느림 힌트. 2026-09-18 실측: 쓰기 없는 경로만 2.4~3.3초, 실제 삽입은 +1~3초 → 정상이 4~6초다.
// 3초였을 땐 매번 떴고 문구가 「첫 전송」·「깨우는 중」이라 거짓이었다(사용자 지적).
// 8초는 정상 범위 밖 — 뜨면 진짜 느린 것이고, 시간 초과까지 기다린다는 뜻을 담는다.
const SLOW_HINT_MS    = 8000;

let myName = "", sheetUrl = "", parsedData = null;
// 게시글을 못 읽었을 때 그 탭의 주소 — 손으로 채워 보낸 글도 요청글 링크·중복 검사를 갖게 한다(5차 점검: 주소가 빠지면
// 서버가 중복 검사를 건너뛰고, 링크 수식이 없어 작업타이머가 영상작업이 아니라 관리항목으로 읽었다)
let failedUrl = "";
let parseSeq = 0;         // 불러오기 순번 — 겹쳐 뜬 불러오기는 마지막 것만 받는다
let parsing = false;      // 불러오는 중 — 끝나기 전에 전송이 열리면 늦게 온 결과가 보내는 중인 폼을 덮어썼다(6차 점검)
// 게시글 주소 판정은 여기 한 곳 — 예전엔 부분 문자열(includes)이라 닮은 주소의 다른 사이트도 게시글로 읽었다
const isPostUrl = u => /^https:\/\/intranet\.adef\.co\.kr\/video\/view(\?|$)/.test(u || "");
let sending = false;      // 전송 중복 진입 차단
let sentKey = "";         // 이 팝업에서 전송 성공한 글(postKey) — 탭을 오가도 다시 안 보내게
let unsureKey = "";       // 응답을 못 받은 전송의 글(postKey) — 다시 보내 「중복」이 오면 사실은 들어간 것
let nameMissing = false;  // 저장된 내 이름이 시트 명단에 없다 — 보내면 서버가 「팀원 이름 없음」으로 거절한다
// 「시트를 확인해 주세요」 안내에 붙이는 바로가기 — 팀 업무현황 시트
const SHEET_URL = "https://docs.google.com/spreadsheets/d/18K3NKAkZwGvxS_QMV5boGNJtmay1ZJ_4xBs26SZZ_Bc/edit";

// ── 즉시 웜업 ────────────────────────────────────────────────
// 콜드 스타트를 미리 깨운다. 실패해도 아무 일 없다.
chrome.storage.local.get(["sheetUrl"], d => {
  fetch((d.sheetUrl || DEFAULT_URL) + "?warmup=1").catch(() => {});
});
// 불러오기 응답보다 먼저 읽혀야 경고가 결과에 덮이지 않는다 — 그래서 맨 앞에서 부른다
checkPending();

// ══════════════════════════════════════════════════════════════
//  표시 헬퍼 — JS 는 색을 만지지 않는다. 클래스만 토글한다.
// ══════════════════════════════════════════════════════════════

// 결과 표시. 대기·진행은 버튼이 말하므로 여기엔 '결과'만 넣는다.
// msg 가 비면 지금 상태 문구(보내는 중·보낼 대상·불러오기 전)로 채운다 — 상자는 숨기지 않는다.
// sheetLink = true 면 문구 끝에 「시트 열기」 바로가기를 붙인다(확인하라고만 하고 길을 안 주던 것).
function showStatus(msg, type, sheetLink) {
  const el = $("status-msg");
  if (!el) return;
  const auto = !msg;
  if (!msg) {
    // v1.5 처럼 상자는 항상 있다 — 비우라고 하면 지금 상태를 쓴다.
    // 상자가 사라졌다 나타나면 아래 버튼이 48px 뛴다.
    const hasTitle = !!$("f-title")?.value.trim();
    if (sending)                         { msg = "구글 시트로 보내는 중이에요…";        type = "info"; }
    else if (nameMissing)                { msg = "설정한 이름(" + myName + ")이 시트 명단에 없어요. 설정 탭에서 다시 골라 주세요."; type = "warn"; }
    else if (hasTitle && sentKey && samePost(sentKey, currentKey())) { msg = "이미 보낸 글이에요 ✓"; type = "success done"; }
    else if (hasTitle)                   { msg = myName + " 시트로 보내요";             type = "success"; }
    else if (parsedData || failedUrl)    { msg = "제목을 넣어야 보낼 수 있어요";        type = "warn"; }   // 막힌 이유를 버튼 title 에만 두지 않는다
    else                                 { msg = "불러오기 전이에요";                   type = ""; }
  }
  el.dataset.auto = auto ? "1" : "";   // 자동 문구면 제목·명단이 바뀔 때 다시 써도 된다(결과 문구는 지키고)
  const cls = "status" + (type ? " " + type : "");
  const sig = msg + "|" + cls + "|" + !!sheetLink;
  if (el.dataset.sig === sig) return;
  el.dataset.sig = sig;
  el.textContent = msg;
  if (sheetLink) {
    const a = document.createElement("a");
    a.href = SHEET_URL; a.target = "_blank"; a.rel = "noopener"; a.className = "st-link";
    a.textContent = "시트 열기";
    el.append(" ", a);
  }
  el.className = cls;
  el.hidden = false;
  // 결과(완료·경고·오류)는 한 번 살짝 떠오르며 바뀐다 — 같은 상자 안에서 글자만 바뀌면 바뀐 줄 모른다
  if (/done|warn|error/.test(type || "")) { void el.offsetWidth; el.classList.add("flash"); }
}

// 설정 탭 결과. 예전엔 alert 과 버튼 라벨 치환으로 흩어져 있었다.
// v1.8.2: 줄은 항상 자리를 차지하고(점프 없음) 글자만 켜졌다 꺼진다.
//   성공·안내는 2.2초 뒤 스스로 꺼진다. 오류·경고는 읽어야 하니 다음 동작까지 남는다.
let settingsStatusTimer = null, settingsStatusClear = null;
function showSettingsStatus(msg, type) {
  const el = $("s-status");
  if (!el) return;
  clearTimeout(settingsStatusTimer); clearTimeout(settingsStatusClear);
  const off = () => {
    el.classList.remove("on");
    settingsStatusClear = setTimeout(() => { if (!el.classList.contains("on")) el.textContent = ""; }, 250);  // 페이드아웃 뒤 비움
  };
  if (!msg) { off(); return; }
  el.textContent = msg;
  el.className = "status slim on" + (type ? " " + type : "");
  if (type !== "error" && type !== "warn") settingsStatusTimer = setTimeout(off, 2200);
}

// 처리자 — v1.5 그대로: 값 상자에 이름, 옆에 개인(파랑)/공동(보라) 배지.
// 시트로 보내지 않는 참고 정보다.
function setAssignee(name) {
  const el = $("f-assignee"), tag = $("f-assignee-tag");
  if (!el) return;
  if (name) { el.textContent = name; el.classList.remove("empty"); }
  else      { el.textContent = "—";  el.classList.add("empty"); }
  if (!tag) return;
  if (name && MEMBERS.includes(name)) {
    tag.textContent = "개인"; tag.className = "assignee-tag badge me";   tag.style.display = "";
  } else if (name) {
    tag.textContent = "공동"; tag.className = "assignee-tag badge team"; tag.style.display = "";
  } else {
    tag.style.display = "none";
  }
}

// 전송 버튼의 세 상태를 한 곳에서 정한다.
function setSendState(state) {
  const b = $("btn-send");
  if (!b) return;
  const target = myName ? myName + " 시트로 전송" : "구글 시트로 전송";
  b.classList.remove("loading");
  b.title = state === "blocked" ? (parsing ? "불러오는 중이에요" : nameMissing ? "설정한 이름이 시트 명단에 없어요" : "제목이 있어야 보낼 수 있어요")
          : state === "done" ? "이미 보낸 글이에요" : "";
  if (state === "sending") {
    b.textContent = "전송 중…";
    b.classList.add("loading");
    b.disabled = true;
  } else if (state === "done") {
    b.textContent = target;
    b.disabled = true;      // 같은 게시글 재전송 방지
  } else if (state === "blocked") {
    b.textContent = target;
    b.disabled = true;      // 제목이 없어 보낼 수 없음
  } else {
    b.textContent = target;
    b.disabled = false;
  }
}

// 제목이 있어야만 보낼 수 있다. 파싱이 실패해도 손으로 채우면 보낼 수 있어야 한다.
function refreshSendGate() {
  if (sending) return;
  const hasTitle = $("f-title").value.trim().length > 0;
  if ($("status-msg")?.dataset.auto === "1") showStatus("");
  if (!hasTitle || nameMissing || parsing) { setSendState("blocked"); return; }
  if (sentKey && samePost(sentKey, currentKey())) { setSendState("done"); return; }
  setSendState("ready");
}

// 다양한 날짜 표기를 <input type="date">용 YYYY-MM-DD로 변환
function toDateInputValue(s) {
  if (!s) return "";
  const m = String(s).match(/(\d{4})\D*(\d{1,2})\D*(\d{1,2})/);
  if (!m) return "";
  return m[1] + "-" + m[2].padStart(2, "0") + "-" + m[3].padStart(2, "0");
}

// 응답이 JSON 이 아닐 때(구글 로그인 리다이렉트, 할당량 초과 등)
// SyntaxError 원문이 사용자에게 그대로 가던 것을 사람이 읽을 문장으로 바꾼다.
async function asJson(res) {
  const text = await res.text();
  if (!res.ok) throw new Error("서버 응답 오류 (" + res.status + ")");
  try { return JSON.parse(text); }
  catch {
    console.error("JSON 아님:", text.slice(0, 300));
    throw new Error("시트 주소가 만료됐거나 접근 권한이 바뀐 것 같아요. 설정 탭에서 연결 테스트를 눌러 보세요.");
  }
}

// ── 팀원 명단 ────────────────────────────────────────────────
function renderMemberOptions(keep) {
  const sel = $("s-myname");
  if (!sel) return;
  // 화면의 현재 선택값이 우선. keep(저장값)은 폴백이다.
  // 반대로 두면 사용자가 이름을 고르는 사이 명단 응답이 도착해 되돌려버린다.
  const cur = sel.value || keep || "";
  sel.innerHTML = '<option value="">— 선택 —</option>';
  MEMBERS.forEach(n => {
    const o = document.createElement("option");
    o.value = n; o.textContent = n;
    sel.appendChild(o);
  });
  if (cur && MEMBERS.indexOf(cur) !== -1) sel.value = cur;
}

// 저장된 이름이 명단에서 사라졌으면 알린다.
// 예전엔 select 만 비고 모듈 변수는 옛 이름을 들고 있어 그대로 전송됐다.
// 예전엔 명단이 「바뀐」 순간에만 불려서, 두 번째 팝업부터 경고가 사라지고(전송이 열려 서버가 거절)
// 안내대로 이름을 다시 골라 저장해도 막힌 채 남았다(4차 점검 B2·B3). 이제 열 때·명단 응답·저장 때마다 다시 판정한다.
function checkMyNameStillValid() {
  const was = nameMissing;
  nameMissing = !!myName && MEMBERS.indexOf(myName) === -1;
  if (nameMissing) {
    // 「지난번 전송 확인」 경고가 떠 있으면 그걸 지킨다 — 막힌 이유는 버튼과 설정 탭이 말한다
    // 자동 문구로 띄운다(showStatus 의 nameMissing 갈래) — 그래야 이름을 다시 골라 풀렸을 때 거둘 수 있다
    if (!($("status-msg")?.textContent || "").startsWith(pendingMessage())) showStatus("");
    showSettingsStatus("설정된 이름(" + myName + ")이 시트 명단에 없어요. 다시 선택해 주세요.", "error");
  } else if (was && $("status-msg")?.dataset.auto === "1") {
    showStatus("");   // 풀렸으면 경고를 거두고 평소 안내로 — 단 「지난번 전송 확인」 같은 결과 문구는 지킨다
  }
  refreshSendGate();
}

// 시트에서 최신 명단 가져오기. 실패해도 캐시/기본값으로 계속 동작.
// action=members 는 업무현황 시트를 읽지 않아 매우 가볍다.
function refreshMembers(url, keep) {
  // v1.8.7: 내 이름·버전을 같이 보낸다 — 서버 v63 이 「누가 어느 버전을 쓰는지」 남긴다(v1.5 사용자 파악용).
  // 옛 서버는 모르는 매개변수를 무시하므로 안전하다.
  const q = "?action=members&ver=" + encodeURIComponent(APP_VER) + (keep ? "&name=" + encodeURIComponent(keep) : "");
  fetch((url || DEFAULT_URL) + q)
    .then(asJson)
    .then(j => {
      if (!j || !j.ok) return;
      // v1.8.4: 팝업을 열 때 바로 안다(서버 v61+ 가 members 응답에 실어 보낸다). 예전엔 전송 응답에만 있었다.
      if (j.latestVer) noteNewVersion(j.latestVer, j.updateMsg);
      if (!Array.isArray(j.members) || !j.members.length) return;
      if (j.members.join("|") !== MEMBERS.join("|")) {
        MEMBERS = j.members.slice();
        chrome.storage.local.set({ memberNames: MEMBERS });
        renderMemberOptions(keep);
      }
      checkMyNameStillValid();   // 명단이 같아도 — 저장해 둔 명단으로 연 경우도 판정해야 한다
    })
    .catch(() => {});
}

// ── 새 버전 알림 ─────────────────────────────────────────────
// 알림은 팝업을 열 때 명단 응답(v1.8.4+)과 전송 응답에 실려 온다. 서버가 잠깐 안 닿아도
// 업데이트할 때까지 계속 보이게 storage 에 남기고, 버전이 올라가면 스스로 지운다.
function showUpdateBar(ver, msg) {
  const bar = $("update-bar");
  if (!bar) return;
  $("update-ver").textContent = "v" + ver;
  const m = $("update-msg"); if (m) m.textContent = msg || "";
  const a = $("update-link");
  if (a) { a.href = RELEASES_URL; a.title = (msg || "").replace(/^[—\-\s]+/, "") || "새 버전 받는 곳"; }
  bar.title = a ? a.title : "";
  bar.classList.add("show");
}

// a < b ? 서버의 verLt 와 같은 규칙 — "1.10" 과 "1.9" 를 문자열로 비교하면 틀리고,
// "1.8" 과 "1.8.3" 을 !== 로 비교하면 이미 올린 뒤에도 옛 알림이 남는다. 자리별 숫자로 본다.
function verLt(a, b) {
  const x = String(a || "0").split("."), y = String(b || "0").split(".");
  const n = Math.max(x.length, y.length);
  for (let i = 0; i < n; i++) {
    const p = parseInt(x[i], 10) || 0, q = parseInt(y[i], 10) || 0;
    if (p !== q) return p < q;
  }
  return false;
}

function noteNewVersion(ver, msg) {
  if (!ver || !verLt(APP_VER, ver)) return;   // 지금 것보다 새 것일 때만
  chrome.storage.local.set({ updateNotice: { ver: ver, msg: msg || "" } });
  showUpdateBar(ver, msg);
}

function restoreUpdateNotice() {
  chrome.storage.local.get(["updateNotice"], d => {
    const n = d.updateNotice;
    if (!n || !n.ver) return;
    if (!verLt(APP_VER, n.ver)) { chrome.storage.local.remove("updateNotice"); return; }   // 이미 그 이상이면 지운다
    showUpdateBar(n.ver, n.msg);
  });
}

// ── 끝나지 않은 전송 경고 ────────────────────────────────────
// 팝업이 닫히면 진행 중인 fetch 는 끊기지만 요청은 이미 나갔다 —
// 서버는 끝까지 실행해 시트에 행을 쓰는데 기록에는 안 남는다.
// 그러면 실패로 알고 다시 눌러 중복이 생긴다.
// v1.8.8: 글마다 따로 남긴다(최대 5건, 하루). 예전엔 한 칸이라 글 B 를 보내면 글 A 의 경고가 지워졌다.
// 열쇠 = 게시글 주소, 주소가 없으면(손으로 채워 보낸 것) 「t:제목」.
const PENDING_MAX = 5, PENDING_TTL = 864e5;
let pendingList = [];      // [{key, at}] — checkPending 이 읽어 둔다
function postKey(url, title) { return url || (title ? "t:" + title : ""); }
function postUrl() { return parsedData?.url || failedUrl; }
function currentKey() { return postKey(postUrl(), $("f-title").value.trim()); }
function savePending() {
  chrome.storage.local.set({ pendingSends: pendingList });
  chrome.storage.local.remove("pendingSend");   // v1.8.7 이하의 한 칸짜리
}
// 쓰기 직전에 저장소를 다시 읽어 합친다 — 팝업이 두 창에 떠 있으면 서로의 기록을 지우지 않게
function updatePending(fn) {
  chrome.storage.local.get(["pendingSends"], d => {
    const stored = Array.isArray(d.pendingSends) ? d.pendingSends : [];
    const merged = stored.concat(pendingList.filter(p => !stored.some(s => s.key === p.key && s.at === p.at)));
    pendingList = fn(merged.filter(p => p && p.key && Date.now() - p.at < PENDING_TTL)).slice(-PENDING_MAX);
    savePending();
  });
}
function markPending(key) {
  if (!key) return;
  pendingList = pendingList.filter(p => !samePost(p.key, key)).concat({ key, at: Date.now() });   // 이 팝업 안에서는 바로 보이게
  updatePending(list => list.filter(p => !samePost(p.key, key)).concat({ key, at: Date.now() }));
}
function clearPending(key) {
  const old = pendingFor(key)?.key;   // 옛 「t:제목」 열쇠로 찾았으면 그것도 지운다
  const gone = p => samePost(p.key, key) || p.key === old;
  pendingList = pendingList.filter(p => !gone(p));
  updatePending(list => list.filter(p => !gone(p)));
}
// v1.8.10 까지 손 전송의 열쇠는 「t:제목」이었다(이제는 탭 주소) — 업데이트 직후 하루 동안 남은 옛 기록도 찾는다
function pendingFor(key) {
  const t = $("f-title")?.value.trim();
  return pendingList.find(p => samePost(p.key, key) || (!parsedData && t && p.key === "t:" + t)) || null;
}
// 예전엔 여기서 기록을 지우고 경고를 띄웠는데, 곧이어 불러오기가 상태 상자를 덮어써서
// 경고가 한 번도 보이지 않은 채 사라졌다(2026-11-28 점검). 이제는 읽어만 두고,
// 그 글을 다시 열었을 때(render) 또는 보내려 할 때(전송 버튼) 실제로 보여 준 뒤에 지운다.
function checkPending() {
  chrome.storage.local.get(["pendingSends", "pendingSend"], d => {
    const list = Array.isArray(d.pendingSends) ? d.pendingSends.slice() : [];
    if (d.pendingSend && d.pendingSend.url) list.push({ key: d.pendingSend.url, at: d.pendingSend.at || 0 });
    pendingList = list.filter(p => p && p.key && p.at && Date.now() - p.at < PENDING_TTL).slice(-PENDING_MAX);
    if (pendingList.length !== list.length || d.pendingSend) savePending();
  });
}
function pendingMessage() {
  return "지난번 전송이 들어갔는지 확실하지 않아요. 시트를 먼저 확인해 주세요.";
}
// 서버의 중복 판정은 글번호(idx) 기준이다 — 주소 뒤에 붙은 다른 매개변수가 달라도 같은 글이다
// 앞 경계([?&])가 있어야 「cate_idx=3」 같은 다른 매개변수를 글번호로 읽지 않는다
function idxOf(u) { return (String(u || "").match(/[?&]idx=(\d+)/) || [])[1] || ""; }
function samePost(a, b) {
  if (!a || !b) return false;
  const x = idxOf(a), y = idxOf(b);
  return x && y ? x === y : a === b;
}
// 지금 불러온 그 글의 전송이 불확실했으면 경고를 보여 주고 true. 보여 준 뒤라야 그 글의 기록을 지운다.
// 다른 글의 기록은 건드리지 않는다 — 그 글을 다시 열 때 경고해야 한다.
function showPendingIfAny() {
  const key = currentKey();
  if (!pendingFor(key)) return false;
  showStatus(pendingMessage(), "warn", true);
  unsureKey = key;          // 다시 보내 「중복」이 오면 성공으로 바로잡는다
  clearPending(key);
  return true;
}

// ── 탭 전환 ─────────────────────────────────────────────────
// 탭 표시는 여기 한 곳에서만 바꾼다(예전엔 첫 실행 경로에 같은 코드가 한 벌 더 있었다).
function showTab(name, focus) {
  document.querySelectorAll(".tab").forEach(t => {
    const on = t.dataset.tab === name;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on ? "true" : "false");
    t.tabIndex = on ? 0 : -1;
    if (on && focus) t.focus();
  });
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.toggle("active", p.id === "tab-" + name));
}
const tabEls = Array.from(document.querySelectorAll(".tab"));
tabEls.forEach((tab, i) => {
  tab.addEventListener("click", () => {
    showTab(tab.dataset.tab);
    if (tab.dataset.tab === "fetch")   refreshFetchTab();
    if (tab.dataset.tab === "history") loadHistory();
  });
  // 탭 목록의 약속(WAI-ARIA): 좌우 화살표로 옆 탭으로 옮겨 간다
  tab.addEventListener("keydown", e => {
    if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
    e.preventDefault();
    const next = tabEls[(i + (e.key === "ArrowRight" ? 1 : tabEls.length - 1)) % tabEls.length];
    next.focus(); next.click();
  });
});

// ── 설정 로드 ────────────────────────────────────────────────
function loadSettings(cb) {
  chrome.storage.local.get(["myName", "sheetUrl", "dupCheck", "memoPSuffix", "memberNames"], d => {
    myName   = d.myName   || "";
    sheetUrl = d.sheetUrl || DEFAULT_URL;
    if (Array.isArray(d.memberNames) && d.memberNames.length) MEMBERS = d.memberNames.slice();
    renderMemberOptions(d.myName || "");
    if (d.myName) $("s-myname").value = d.myName;
    checkMyNameStillValid();   // 저장해 둔 명단으로 먼저 판정(서버가 안 닿아도), 명단 응답이 오면 한 번 더
    refreshMembers(sheetUrl, d.myName || "");
    $("s-sheet-url").value  = sheetUrl;
    $("s-dupcheck").checked = d.dupCheck !== false;
    const mpt = $("memo-p-toggle");
    if (mpt) { mpt.checked = !!d.memoPSuffix; syncMemoPlaceholder(); }
    touchDevice();
    if (cb) cb();
  });
}

// 직접 입력이 있으면 위 선택은 무시된다. 그걸 화면에 드러낸다(코드로 값을 바꾼 뒤에도 부른다).
function syncCustomLink() {
  const on = $("f-link-custom").value.trim().length > 0;
  $("f-links").classList.toggle("ignored", on);
  $("f-link-ignore").hidden = !on;
  refreshPlanButton();
}

function syncMemoPlaceholder() {
  const on = !!$("memo-p-toggle")?.checked;
  $("f-memo").placeholder = on ? "메모 기록 (끝에 p가 붙어요)" : "메모 기록 (선택)";
}

document.addEventListener("DOMContentLoaded", () => {
  $("app-ver").textContent = "· v" + APP_VER;
  restoreUpdateNotice();

  $("update-link")?.addEventListener("click", () => {
    showStatus("받은 zip 을 지금 폴더에 덮어쓰고 chrome://extensions 에서 ↻, 인트라넷 탭은 F5 해 주세요.", "info");
  });
  $("btn-goto-settings")?.addEventListener("click", () => showTab("settings", true));
  $("update-x")?.addEventListener("click", () => {
    $("update-bar").classList.remove("show");   // 이번 팝업에서만 숨김 — 다음에 다시 뜬다
  });

  $("s-dupcheck")?.addEventListener("change", e => {
    chrome.storage.local.set({ dupCheck: e.target.checked });
  });
  $("memo-p-toggle")?.addEventListener("change", e => {
    chrome.storage.local.set({ memoPSuffix: e.target.checked });
    syncMemoPlaceholder();
  });

  // 제목을 손으로 채우면 전송이 열린다 — 파싱이 실패해도 쓸 수 있어야 한다
  $("f-title")?.addEventListener("input", refreshSendGate);

  // 직접 입력이 있으면 위 선택은 무시된다. 그걸 화면에 드러낸다.
  $("f-link-custom")?.addEventListener("input", syncCustomLink);
  $("f-links")?.addEventListener("change", refreshPlanButton);

  // 팝업 어디서든 Enter = 전송. 단 아래는 그 요소 본래 동작을 살린다:
  //  - 한글 조합을 끝내는 Enter(조합 확정 직후 오전송 방지)
  //  - 키 자동반복(누르고 있으면 여러 번 발화)
  //  - select/버튼/링크/체크박스 등
  //  - 희망완료일 칸(readonly 라 포커스는 받는데 캘린더 트리거가 click 뿐이라
  //    Enter 가 그대로 전송으로 새던 것)
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    if (e.isComposing || e.keyCode === 229) return;
    if (e.repeat) return;
    const t = e.target;
    const tag = (t && t.tagName) ? t.tagName.toUpperCase() : "";
    const type = (t && t.type) ? String(t.type).toLowerCase() : "";
    if (t && t.id === "f-duedate") { e.preventDefault(); openDatePicker(); return; }
    if (tag === "SELECT" || tag === "BUTTON" || tag === "A" || tag === "TEXTAREA") return;
    if (type === "checkbox" || type === "radio") return;
    const fetchPanel = $("tab-fetch");
    const mainState  = $("state-main");
    if (!fetchPanel || !fetchPanel.classList.contains("active")) return;
    if (!mainState || mainState.style.display === "none") return;
    e.preventDefault();
    $("btn-send")?.click();   // 비활성이면 자연히 무시된다
  });

  // 희망완료일: 칸을 클릭(또는 Enter/Space)하면 캘린더, 고르면 텍스트칸을 ISO로 채움
  const dueText = $("f-duedate"), duePicker = $("f-duedate-picker");
  dueText?.addEventListener("click", openDatePicker);
  dueText?.addEventListener("keydown", e => {
    if (e.key === " ") { e.preventDefault(); openDatePicker(); }
    if (e.key === "Backspace" || e.key === "Delete") { e.preventDefault(); setDue(""); }   // 읽기 전용 칸이라 키로 지울 길을 따로 둔다
  });
  // 달력의 「삭제」는 빈 값으로 온다 — 예전엔 무시해서 틀린 마감일을 지울 방법이 없었다(5차 점검)
  duePicker?.addEventListener("change", e => setDue(e.target.value));
});

function setDue(iso) {
  $("f-duedate").value = iso;
  $("f-duedate").classList.toggle("empty", !iso);
  $("f-duedate-picker").value = iso;
}

function openDatePicker() {
  const p = $("f-duedate-picker");
  if (!p) return;
  try { p.showPicker(); }
  catch (e) { p.focus(); p.click(); }   // 폴백
}

// ── 설정 저장 ────────────────────────────────────────────────
$("btn-save").addEventListener("click", () => {
  const name = $("s-myname").value;
  const url  = $("s-sheet-url").value.trim();
  if (!name) { showSettingsStatus("이름을 선택해 주세요.", "warn"); $("s-myname").focus(); return; }
  if (!url)  { showSettingsStatus("시트 주소를 입력해 주세요.", "warn"); $("s-sheet-url").focus(); return; }
  // 아무 글자나 저장되면 전송 실패가 「연결이 끊겼어요 · 지난 전송 불확실」로 둔갑했다(6차 점검). 권한(host_permissions)도 이 호스트뿐이다
  if (url !== sheetUrl && !/^https:\/\/script\.google\.com\/(a\/macros\/[^/\s]+\/|a\/[^/\s]+\/macros\/|macros\/)s\/[^/\s]+\/exec$/.test(url)) {
    showSettingsStatus("웹앱 주소(…/exec)가 아니에요. 주소를 확인해 주세요.", "warn"); $("s-sheet-url").focus(); return;
  }
  const firstRun = !myName;
  chrome.storage.local.set({ myName: name, sheetUrl: url, dupCheck: $("s-dupcheck").checked }, () => {
    myName = name; sheetUrl = url;
    showSettingsStatus("저장했어요.", "success");
    checkMyNameStillValid();   // 안내대로 이름을 다시 골랐으면 여기서 전송이 풀린다
    // 처음 설정이면 바로 쓸 수 있게 가져오기 탭으로 넘어간다(예전엔 탭을 한 번 더 눌러야 했다)
    if (firstRun) setTimeout(() => {
      // 그사이 다른 탭을 눌렀으면 끌고 가지 않는다
      if (document.querySelector(".tab.active")?.dataset.tab === "settings") { showTab("fetch", true); refreshFetchTab(); }
    }, 600);
    refreshFetchTab();
  });
});

// ── 연결 테스트 ──────────────────────────────────────────────
$("btn-test").addEventListener("click", async () => {
  const url = $("s-sheet-url").value.trim();
  const b = $("btn-test");
  if (!url) { showSettingsStatus("시트 주소를 입력해 주세요.", "warn"); return; }
  b.disabled = true;
  b.classList.add("loading");
  showSettingsStatus("");
  const started = Date.now();
  try {
    const data = await fetch(url + "?test=1", { signal: AbortSignal.timeout(15000) }).then(asJson);   // 응답이 없으면 버튼이 영영 잠겼다
    await minDelay(started);
    showSettingsStatus(data.ok ? "연결됐어요." : "응답이 이상해요. 주소를 확인해 주세요.", data.ok ? "success" : "error");
  } catch (e) {
    await minDelay(started);
    // 통신 실패(시간 초과·연결 끊김)는 브라우저의 영어 원문 대신 할 일로 — asJson 이 만든 진단 문구만 그대로
    const net = e instanceof TypeError || /Abort|Timeout/.test(e.name);
    showSettingsStatus(net ? "연결하지 못했어요. 주소와 인터넷을 확인해 주세요." : (e.message || "연결에 실패했어요."), "error");
  } finally {
    b.disabled = false;
    b.classList.remove("loading");
  }
});

// 응답이 너무 빨리 오면 '확인 중'이 한 프레임 깜빡이고 사라진다
function minDelay(started, ms) {
  const left = (ms || 400) - (Date.now() - started);
  return left > 0 ? new Promise(r => setTimeout(r, left)) : Promise.resolve();
}

// ── 기록 (chrome.storage.sync) ──────────────────────────────
// sync 는 항목당 8KB(UTF-8 바이트) 제한. String.length 는 UTF-16 코드유닛이라
// 한글에서 3배 차이가 난다 — TextEncoder 로 실제 바이트를 잰다.
function byteLen(s) {
  try { return new TextEncoder().encode(s).length; }
  catch { return s.length * 3; }
}

// sync 와 local 을 합친다 — url 로 중복 제거, 날짜(yy/mm/dd) 내림차순, 같은 날이면 앞에 온 것 우선.
// 예전엔 sync 쓰기가 실패하면 local 로 떨어졌다가, 다음에 sync 가 성공하면 그 local 을 지웠다.
// 한쪽 PC 에 쌓인 기록이 합쳐지지 않고 사라지는 경로였다.
function mergeHistory() {
  const seen = new Set(), out = [];
  for (const list of arguments) {
    (list || []).forEach(h => {
      const k = h && (h.url || (h.title ? "t:" + h.title + "|" + (h.date || "") : ""));   // 주소 없는 손 전송도 남긴다
      if (!k || seen.has(k)) return;
      seen.add(k); out.push(h);
    });
  }
  out.sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));   // 안정 정렬
  return out;
}

function saveHistory(item) {
  chrome.storage.sync.get(["history"], d => {
    chrome.storage.local.get(["history"], l => {
      const fresh = { title: (item.title || "").slice(0, 60), url: item.url || "", date: item.date };
      let hist = mergeHistory([fresh], d.history, l.history);
      if (hist.length > MAX_HISTORY) hist = hist.slice(0, MAX_HISTORY);
      while (hist.length > 1 && byteLen(JSON.stringify({ history: hist })) > 7500) hist.pop();
      // local 은 항상 같이 쓴다 — sync 가 안 되는 PC 에서도 기록은 남아야 하고,
      // 나중에 sync 가 붙으면 위 merge 가 알아서 합친다. 지우지 않는다.
      chrome.storage.local.set({ history: hist });
      chrome.storage.sync.set({ history: hist });
    });
  });
}

function loadHistory() {
  chrome.storage.sync.get(["history"], d => {
    chrome.storage.local.get(["history"], l => {
      renderHistory(mergeHistory(d.history, l.history).slice(0, MAX_HISTORY));
    });
  });
}

// ── 동기화 도장 ─────────────────────────────────────────────
// chrome.storage.sync 는 크롬이 같은 구글 계정으로 로그인 + 동기화 켜짐일 때만 PC 를 넘어간다.
// 아니면 크롬이 조용히 local 처럼 동작한다 — 오류도 없고 화면도 같아서 구별이 안 됐다.
// 그래서 PC 마다 도장을 sync 에 찍는다. 다른 PC 도장이 보이면 동기화가 실제로 건너온 것이다.
function touchDevice() {
  chrome.storage.local.get(["deviceId"], l => {
    let id = l.deviceId;
    if (!id) {
      id = (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
      chrome.storage.local.set({ deviceId: id });
    }
    chrome.storage.sync.get(["devices"], d => {
      const dev = d.devices || {}, now = Date.now();
      dev[id] = now;
      Object.keys(dev).forEach(k => { if (now - dev[k] > 60 * 864e5) delete dev[k]; });   // 60일 안 본 PC 는 정리
      chrome.storage.sync.set({ devices: dev }, () => renderSyncStatus(id, dev, !!chrome.runtime.lastError));
    });
  });
}

function renderSyncStatus(myId, dev, failed) {
  const el = $("s-sync");
  if (!el) return;
  const others = Object.keys(dev).filter(k => k !== myId);
  if (failed) {
    el.textContent = "기록 동기화 · 저장소에 못 썼어요. 이 PC 에만 남아요.";
  } else if (!others.length) {
    el.textContent = "기록 동기화 · 다른 PC 는 아직 안 보여요 — 크롬이 같은 구글 계정으로 동기화 중이어야 해요.";
  } else {
    const last = new Date(Math.max.apply(null, others.map(k => dev[k])));
    const mm = String(last.getMonth() + 1).padStart(2, "0"), dd = String(last.getDate()).padStart(2, "0");
    const hh = String(last.getHours()).padStart(2, "0"), mi = String(last.getMinutes()).padStart(2, "0");
    el.textContent = "기록 동기화 · 다른 PC " + others.length + "대와 함께 써요 (그쪽 마지막 " + mm + "/" + dd + " " + hh + ":" + mi + ")";
  }
  // 확장 ID — 두 PC 가 같아야 동기화가 붙는다. 마우스 올리면 보인다.
  el.title = "확장 ID " + (chrome.runtime.id || "") + " — 두 PC 에서 같아야 해요";
}

// 게시글 제목은 남이 쓴 문자열이다. innerHTML 로 조립하면
// '<A안>' 같은 ASCII 시작 꺾쇠가 태그로 파싱돼 줄이 사라진다.
function renderHistory(hist) {
  const listEl = $("history-list");
  $("history-empty").hidden  = hist.length > 0;
  $("history-footer").style.display = hist.length ? "flex" : "none";
  listEl.innerHTML = "";
  hist.forEach(h => {
    const a = document.createElement("a");
    a.className = "history-item";
    a.target = "_blank";
    if (/^https?:\/\//i.test(h.url || "")) a.href = h.url;
    const t = document.createElement("div");
    t.className = "history-title";
    t.textContent = h.title || h.url || "(제목 없음)";
    const dt = document.createElement("div");
    dt.className = "history-date";
    dt.textContent = h.date || "";
    a.append(t, dt);
    listEl.appendChild(a);
  });
}

// 기록 전체 삭제 — sync 라 같은 계정의 다른 PC 에서도 지워지고 되돌릴 수 없다.
// 예전엔 무장 후 최소 대기가 없어 더블클릭이면 확인 없이 실행됐다.
let confirmTimer = null;
$("btn-clear-history").addEventListener("click", () => {
  const b = $("btn-clear-history");
  if (b.dataset.confirm !== "1") {
    b.dataset.confirm = "1";
    b.dataset.armedAt = String(Date.now());
    b.textContent = "정말 삭제할까요?";
    b.classList.remove("quiet");
    b.classList.add("danger", "arming");
    clearTimeout(confirmTimer);
    confirmTimer = setTimeout(() => disarmClear(), 3000);
    return;
  }
  if (Date.now() - Number(b.dataset.armedAt || 0) < 400) return;   // 더블클릭 오폭 차단
  clearTimeout(confirmTimer);
  chrome.storage.sync.remove("history", () => {
    chrome.storage.local.remove("history", () => {
      disarmClear();
      loadHistory();
    });
  });
});

function disarmClear() {
  const b = $("btn-clear-history");
  if (!b) return;
  b.dataset.confirm = "0";
  b.textContent = "기록 전체 삭제";
  b.classList.remove("danger", "arming");
  b.classList.add("quiet");
}

// ── 가져오기 탭 갱신 ────────────────────────────────────────
function refreshFetchTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const isIntranet = isPostUrl(tabs[0]?.url);
    $("state-not-intranet").style.display = "none";
    $("state-no-settings").style.display  = "none";
    $("state-main").style.display         = "none";

    if (!isIntranet) {
      $("state-not-intranet").style.display = "block";
    } else if (!myName || !sheetUrl) {
      $("state-no-settings").style.display = "block";
    } else {
      $("state-main").style.display = "block";
      // 읽기에 실패한 그 글이면 다시 읽지 않는다 — 손으로 채우던 칸이 다시 읽기 실패로 지워지던 것(5차 점검)
      if (!parsedData && !(failedUrl && failedUrl === tabs[0].url)) parseTab(tabs[0].id, tabs[0].url);
      else refreshSendGate();
    }
    document.body.classList.add("ready");
  });
}

// ── 초기 화면 ────────────────────────────────────────────────
loadSettings(() => {
  if (!myName) {
    showTab("settings");
    document.body.classList.add("ready");
  } else {
    refreshFetchTab();
  }
});

// ── 불러오기 ────────────────────────────────────────────────
// manifest 가 이미 content.js 를 주입하므로 먼저 말을 걸어 본다.
// 확장을 갓 설치했거나 탭을 아직 새로고침하지 않은 경우에만 주입한다.
// 예전엔 매번 executeScript 로 다시 주입하고 200ms 를 기다렸는데,
// 그 200ms 는 기다릴 대상이 없었고 리스너만 팝업 열 때마다 쌓였다.
let lastTabUrl = "";   // 불러오기를 시작한 탭의 주소 — 실패하면 failedUrl 이 된다
function parseTab(tabId, url) {
  // 보내는 중에 불러오면 방금 보낸 글을 「지난번 전송」으로 오인해 경고하고 그 기록을 지웠다(5차 점검)
  if (sending) return;
  lastTabUrl = url || "";
  parsing = true;
  const seq = ++parseSeq;
  setSendState("blocked");
  showStatus("불러오는 중…", "info");
  chrome.tabs.sendMessage(tabId, { action: "parsePage" }, res => {
    if (chrome.runtime.lastError) return injectThenParse(tabId, seq);
    render(res, seq);
  });
}

function injectThenParse(tabId, seq) {
  chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
    if (chrome.runtime.lastError) return renderFailure(seq);
    chrome.tabs.sendMessage(tabId, { action: "parsePage" }, res => {
      if (chrome.runtime.lastError) return renderFailure(seq);
      render(res, seq);
    });
  });
}

// 파싱이 통째로 실패해도 폼은 살려 둔다 — 손으로 채워 보낼 수 있어야 한다.
function renderFailure(seq) {
  if (seq && seq !== parseSeq) return;   // 더 새 불러오기가 떠 있다
  parsing = false;
  if (sending) return;   // 보내는 중인 폼은 건드리지 않는다
  const sameAsBefore = samePost(parsedData?.url || failedUrl, lastTabUrl);
  parsedData = null;
  failedUrl = isPostUrl(lastTabUrl) ? lastTabUrl : "";
  // 앞 글 내용이 남은 채 전송이 열리면 주소 없이(=서버 중복 검사 없이) 같은 글이 두 번 들어간다(4차 점검 B1).
  // 단 같은 글을 다시 읽다 실패한 것이면 지우지 않는다 — 손으로 채운 칸이 「불러오기」 한 번에 날아갔다(6차 점검)
  if (!sameAsBefore) {
    ["f-title", "f-duedate", "f-link-custom", "f-memo"].forEach(id => { $(id).value = ""; });
    $("f-duedate-picker").value = "";
    $("f-links").innerHTML = '<option value="">— 선택하세요 —</option>';
    setAssignee("");
  }
  $("f-title").classList.toggle("empty", !$("f-title").value.trim());
  syncCustomLink();
  if (showPendingIfAny()) { /* 지난번 전송 확인이 먼저 */ }
  else if (nameMissing) showStatus("");
  else showStatus("게시글을 읽지 못했어요. 직접 채워서 보내도 돼요.", "warn");
  refreshSendGate();
  fillPlanPages();
  refreshPlanButton();
}

function render(res, seq) {
  if (seq && seq !== parseSeq) return;
  if (!res?.success) return renderFailure(seq);
  parsing = false;
  if (sending) return;   // 보내는 중인 폼은 건드리지 않는다
  const prev = parsedData, prevUrl = prev?.url || failedUrl;   // 읽기 실패했던 그 글을 다시 읽은 것도 같은 글이다
  parsedData = res.data;
  failedUrl = "";

  // 같은 게시글을 다시 불러온 것이면 손으로 쓰던 메모·직접 입력 링크를 지킨다(다른 글이면 비운다)
  const sameDoc = !!prevUrl && samePost(prevUrl, parsedData.url);
  const keptMemo = sameDoc ? $("f-memo").value : "";

  $("f-title").value = parsedData.title || "";
  $("f-title").classList.toggle("empty", !parsedData.title);

  const dueISO = toDateInputValue(parsedData.dueDate);
  $("f-duedate").value = dueISO;
  $("f-duedate").classList.toggle("empty", !dueISO);
  $("f-duedate-picker").value = dueISO;

  setAssignee(parsedData.assignee);
  $("f-memo").value = keptMemo;
  $("f-link-custom").value = sameDoc ? $("f-link-custom").value : "";
  syncCustomLink();

  // 기획안 링크 후보
  const sel = $("f-links");
  sel.innerHTML = '<option value="">— 선택하세요 —</option>';
  const groups = { link: "외부 링크", nas: "NAS 경로", file: "첨부파일" };
  const grouped = {};
  (parsedData.linkCandidates || []).forEach(c => {
    const t = c.type || "link";
    (grouped[t] = grouped[t] || []).push(c);
  });
  Object.entries(groups).forEach(([type, label]) => {
    if (!grouped[type]?.length) return;
    const og = document.createElement("optgroup");
    og.label = label;
    grouped[type].forEach(c => {
      const o = document.createElement("option");
      o.value = c.value; o.textContent = c.label.slice(0, 60);
      og.appendChild(o);
    });
    sel.appendChild(og);
  });

  // '기획안 링크' 라벨에서 온 후보가 있을 때만 자동 선택한다.
  // 예전엔 본문의 아무 첫 링크(공지·푸터 pdf 등)가 조용히 선택돼 시트에 박혔다.
  const hasPrimary = (parsedData.linkCandidates || []).some(c => c.primary);
  if (hasPrimary) { sel.selectedIndex = 1; sel.classList.remove("empty"); }
  else { sel.selectedIndex = 0; sel.classList.toggle("empty", (parsedData.linkCandidates || []).length > 0); }

  if (showPendingIfAny()) {
    // 지난번 전송 경고가 불러오기 안내보다 먼저다 — 확인 안 하고 다시 보내면 두 줄이 생긴다
  } else if (nameMissing) {
    showStatus("");   // 보낼 수 없는 이유가 불러오기 안내보다 먼저다
  } else if (!parsedData.title) {
    showStatus("제목을 못 읽었어요. 직접 입력해 주세요.", "warn");
  } else if (!hasPrimary && (parsedData.linkCandidates || []).length) {
    showStatus("기획안 링크를 못 찾았어요. 직접 골라 주세요.", "warn");
  } else {
    showStatus("");
  }
  refreshSendGate();
  fillPlanPages();
  refreshPlanButton();
}

// ── 기획안 열기 ─────────────────────────────────────────────
// 게시글의 「53~55페이지」를 보고 기획안을 53쪽에서 연다(content.js findPlanPages).
// 쪽 칸은 사람이 고칠 수 있고, 비우면 링크 그대로(보통 첫 장) 연다.
// 구글 슬라이드는 #slide=53(1부터, 실측 확인), PDF 는 #page=53. 그 밖의 링크는 쪽 번호 없이 연다.
function planOpenUrl() {
  const link = $("f-link-custom").value.trim() || $("f-links").value;
  let u;
  try { u = new URL(link); } catch { return null; }
  if (!/^https?:$/.test(u.protocol)) return null;   // NAS 경로 등은 브라우저로 못 연다
  const page = parseInt($("f-plan-page").value, 10);
  if (page > 0) {
    if (u.hostname === "docs.google.com" && u.pathname.startsWith("/presentation/")) {
      u.searchParams.delete("slide");   // ?slide=id.xxx 가 남아 있으면 #slide=N 보다 먼저 먹는다
      u.hash = "slide=" + page;
    } else if (/\.pdf$/i.test(u.pathname)) {
      u.hash = "page=" + page;
    }
  }
  return u.href;
}

function refreshPlanButton() {
  const b = $("btn-plan"), off = !planOpenUrl();
  b.disabled = off;
  b.title = off ? "열 수 있는 기획안 링크가 없어요 (링크를 고르거나 직접 입력해 주세요)" : "기획안을 새 탭으로 열어요";
}

// 불러올 때마다 본문의 쪽 번호로 다시 채운다. 링크만 바꿀 때는 건드리지 않아 사람이 고친 값이 남는다
function fillPlanPages() {
  const pages = parsedData?.planPages || [];
  $("f-plan-page").value = pages[0] || "";
  $("plan-pages").replaceChildren(...pages.map(n => Object.assign(document.createElement("option"), { value: n })));
  $("f-plan-page").title = pages.length > 1
    ? "본문에 적힌 쪽: " + pages.join(" · ") + " — 칸을 비우면 목록이 떠요"
    : "기획안에서 열 쪽 번호 — 비워 두면 링크 그대로 열어요";
}

function openPlan() {
  const url = planOpenUrl();
  if (url) chrome.tabs.create({ url });
}
$("btn-plan").addEventListener("click", openPlan);
$("f-plan-page").addEventListener("input", (e) => {
  e.target.value = e.target.value.replace(/\D/g, "");
});
// 쪽 칸의 Enter 는 전송이 아니라 기획안 열기
$("f-plan-page").addEventListener("keydown", (e) => {
  if (e.key !== "Enter" || e.isComposing) return;
  e.preventDefault();
  e.stopPropagation();
  openPlan();
});

$("btn-parse").addEventListener("click", () => {
  if (sending) return;
  showStatus("");
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => parseTab(tabs[0].id, tabs[0].url));
});

// 서버(작업타이머와 공유)는 개발자용 문구를 돌려준다. 사용자가 다음에 할 일로 바꿔 보여 준다.
function humanError(err, who) {
  const e = String(err || "");
  if (/팀원 이름 없음|이름을 찾을 수 없음/.test(e))
    return { msg: "시트에서 " + (who || myName) + " 구역을 찾지 못했어요. 설정 탭의 이름과 시트의 이름 칸을 확인해 주세요.", sheet: true };
  if (/멈췄|섹션 범위|경계/.test(e))
    return { msg: "시트 구역 경계가 이상해서 안전하게 멈췄어요. 시트를 확인해 주세요.", sheet: true };
  if (/진행 중|busy/i.test(e))
    return { msg: "다른 사람이 저장하는 중이에요. 잠시 뒤 다시 보내 주세요.", sheet: false };
  // 앞말·「시트 열기」까지 두 줄에 들어가는 길이(실측: 한글 30자면 3줄 → 알림 띠와 합쳐 601px)
  const short = e.length > 20 ? e.slice(0, 20) + "…" : e;
  return { msg: e ? "보내지 못했어요 — " + short : "알 수 없는 오류가 났어요.", sheet: true };
}

// ── 전송 ────────────────────────────────────────────────────
// 시트에 들어간 것이 확인되면 여기 한 곳에서 마무리한다(정상 응답 · 응답을 놓친 뒤의 「중복」 응답)
function historyEntry() {
  return {
    title: $("f-title").value.trim() || "(제목 없음)",
    url:   postUrl(),
    date:  new Date().toLocaleDateString("ko-KR", { year: "2-digit", month: "2-digit", day: "2-digit" })
                     .replace(/\.\s*$/, "").replace(/\.\s*/g, "/"),
  };
}
function recordSent(msg, key, keepMemo) {
  clearPending(key);
  unsureKey = "";
  sentKey = key;
  showStatus(msg, keepMemo ? "warn" : "success done", !!keepMemo);
  if (!keepMemo) $("f-memo").value = "";
  saveHistory(historyEntry());
  sending = false;
  setSendState("done");
  // 초점이 꺼진 전송 버튼에 있다가 body 로 떨어지면 키보드 사용자가 길을 잃는다 — 다음 할 일(불러오기)로
  // (크롬은 꺼진 버튼에 초점을 잠깐 남겨 뒀다가 나중에 body 로 옮긴다 — 둘 다 본다)
  const ae = document.activeElement;
  if (sendHadFocus && (!ae || ae === document.body || ae === $("btn-send"))) $("btn-parse")?.focus();
}
let sendHadFocus = false;

$("btn-send").addEventListener("click", async () => {
  const b = $("btn-send");
  if (sending || b.disabled) return;
  sendHadFocus = document.activeElement === b;
  const key = currentKey();
  // 손으로 채워 보내는 글은 불러오기 때 경고할 수 없다 — 보내려는 순간 한 번 멈춰 세운다(다시 누르면 보낸다).
  // 이 팝업에서 방금 실패해 이미 「시트를 확인한 뒤 다시 보내 주세요」라고 말한 글이면 또 멈추지 않는다.
  if (pendingFor(key) && !samePost(unsureKey, key)) { showPendingIfAny(); return; }
  sending = true;
  setSendState("sending");
  showStatus("");
  const who = myName;   // 응답을 기다리는 사이 설정을 바꿔도 실제로 보낸 구역 이름으로 말한다

  const planLink = $("f-link-custom").value.trim() || $("f-links").value;
  let memoVal = $("f-memo").value.trim();
  if (memoVal && $("memo-p-toggle")?.checked) memoVal += "p";

  const body = new URLSearchParams({
    targetMember: who,
    title:        $("f-title").value.trim()    || "",
    dueDate:      toDateInputValue($("f-duedate").value) || "",
    planLink:     planLink             || "",
    memo:         memoVal              || "",
    url:          postUrl(),
    dupCheck:     ($("s-dupcheck").checked || samePost(unsureKey, key)) ? "1" : "0",   // 응답을 놓친 글은 항상 중복 확인
    ver:          APP_VER,
  }).toString();

  const ac = new AbortController();
  const to = setTimeout(() => ac.abort(), SEND_TIMEOUT_MS);
  const slow = setTimeout(() => {
    showStatus("평소보다 오래 걸려요. " + SEND_TIMEOUT_MS / 1000 + "초까지 기다려 볼게요…", "info");   // 경고색 아님: 느린 것이지 잘못된 게 아니다
  }, SLOW_HINT_MS);

  markPending(key);

  try {
    const data = await fetch(sheetUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
      signal: ac.signal,
      keepalive: true,   // 팝업이 닫혀도 요청이 끝까지 나가도록
    }).then(asJson);

    clearTimeout(slow);
    if (data.latestVer) noteNewVersion(data.latestVer, data.updateMsg);

    if (data.duplicate && samePost(unsureKey, key) && !$("s-dupcheck").checked) {
      // 중복 확인을 꺼 둔 사람은 같은 글을 일부러 여러 번 넣기도 한다 — 「중복」이 예전 행 때문일 수 있어 성공이라 단정하지 않는다.
      // 확인은 한 번만 강제한다: 다시 누르면 꺼 둔 설정대로 보낸다(6차 점검 — 거짓 「들어가 있어요 ✓」)
      clearPending(key);
      unsureKey = "";
      saveHistory(historyEntry());   // 들어갔을 가능성이 크다 — 기록 탭에는 남긴다
      showStatus("같은 글이 시트에 이미 있어요. 방금 보낸 건지 확인해 주세요.", "warn", true);
      sending = false;
      setSendState("ready");
    } else if (data.duplicate && samePost(unsureKey, key)) {
      // 응답을 못 받았던 그 전송이 실제로는 들어가 있었다 — 실패가 아니라 성공으로 마무리한다
      recordSent("응답이 늦었지만 " + who + " 시트에 들어가 있어요 ✓", key);
    } else if (data.duplicate) {
      clearPending(key);
      // 제목이 같은 다른 글이 있으면 사람 눈엔 구별이 안 된다 — 보낸 글번호를 같이 보여준다(2026-11-27 주지현 님 제보)
      const no = parsedData?.idx || idxOf(postUrl());
      showStatus("이미 등록된 게시글이에요" + (no ? " · 글번호 " + no : ""), "warn", true);
      sending = false;
      setSendState("ready");
    } else if (data.ok && data.partial) {
      // 행은 들어갔는데 뒤 단계(메모·서식·빈 줄)가 실패했다 — 메모를 지우지 않고 확인하라고 한다(서버 v70~)
      recordSent("시트에 넣었지만 마무리 일부를 못 했어요. 메모·간격 줄을 확인해 주세요.", key, true);
    } else if (data.ok) {
      recordSent(who + " 시트에 추가했어요 ✓", key);
    } else {
      // 응답을 놓친 글을 다시 보냈다가 오류·busy 가 온 것이면 앞선 전송의 불확실함은 그대로다 — 기록을 지우지 않는다(6차 점검)
      if (!samePost(unsureKey, key)) clearPending(key);
      const he = humanError(data.error, who);
      showStatus(he.msg, "error", he.sheet);
      sending = false;
      setSendState("ready");
    }
  } catch (e) {
    clearTimeout(slow);
    sending = false;
    setSendState("ready");
    // 요청이 서버에 닿았을 수 있는 실패(시간 초과·연결 끊김·서버가 이상한 응답)는 pendingSends 에 남기고,
    // 다시 보내 「중복」이 오면 위에서 성공으로 바로잡는다. 「다시 눌러 주세요」만 권하면 두 줄이 생긴다.
    unsureKey = key;
    if (e.name === "AbortError") {
      showStatus("응답이 없어요. 들어갔을 수 있으니 시트를 확인한 뒤 다시 보내 주세요.", "error", true);
    } else if (e instanceof TypeError) {
      showStatus("연결이 끊겼어요. 들어갔는지 시트를 확인한 뒤 다시 보내 주세요.", "error", true);
    } else {
      // asJson 이 만든 진단 문구(주소 만료·서버 응답 오류 NNN)는 그대로 보여 준다
      showStatus(e.message || "전송에 실패했어요.", "error", true);
    }
  } finally {
    clearTimeout(to);
  }
});
